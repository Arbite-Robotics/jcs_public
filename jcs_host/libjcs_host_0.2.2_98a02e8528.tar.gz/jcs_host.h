/*//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//                                                            _   ____ ____  ______________ 
//                                                           / \ | __ \ _  \|_\__ __/  _  / 
//                                                          /   \|   _/  __/| | | | |   \/  
//                                                         / /\  \ \ \| __ \| | | | |  _/\  
//                                                        /_//____\|\_\____/|_| |_| |_____\ 
//                                                       --–-––-–––R O B O T I C S–––-––-–--
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// jcs_host.h - Joint Control System (JCS) dev_host API
//
// Copyright (c) 2024 Arbite Robotics Pty Ltd
// https://arbite.io
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////*/
#ifndef JCS_HOST_H_
#define JCS_HOST_H_

#include <string>
#include <vector>
#include <memory>

#include "jcs_host_types.h"

namespace jcs
{

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// This is the primary interface into a JCS system.
// 
// Unless otherwise specified all methods and functions return an int that defines the success of the function.
// See jcs_host_types.h for return values.
// 
// Methods appended with unsafe do not check vector bounds when indexing.
class jcs_host {
public:
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // JCS host builder
    // Creates an instance of JCS host and does basic initialisation.
    // Returns nullptr if initialisation fails.
    static jcs_host* make_jcs_host(std::string const& config_path, bool print_debug_messages=false, bool print_rt_messages=false);

    // Build JCS host with constructor and initialise.
    jcs_host(std::string const& config_path, bool print_debug_messages=false, bool print_rt_messages=false);
    int initialise();

    ~jcs_host();



    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    //                                                           O P E R A T I O N   A P I 
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //////_ Network and device initialisation
    // Returns true if the system is ready to recieve parameters
    bool cyclic_ready();

    // Start the network and initialise devices and processes from configuration files
    // only_init_jc: If set to true, only initialise joint controllers then return
    int start_network(bool only_init_jc=false);
    
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //////_ User lists and control
    // Calls the user list `list_ready_dev`
    int ready_devices();

    // Calls the user list `list_start`
    // Starts transition into cyclic mode
    int start();

    // Calls the user list `list_stop`
    // Exits sync/cyclic mode
    int stop();

    // Calls the user list `list_shutdown`
    // Exits cycle mode then shutdowns JCS
    int shutdown();


    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //////_ Real time funcions
    // Propagate the real-time system one timestep forward
    // new_cycle_period_ns: Computed new cyclic period to be passed to the real-time system
    int step_rt(long int* new_cycle_period_ns);

    // Returns true if the system is ready to exchange synchronous data
    bool data_is_valid_rt();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //////_ Estop functions
    // Trigger an E-stop and propagate the E-stop to the network
    void trigger_estop();
    // Returns true if the system is in an estop condition
    bool has_estop();

    // Soft reset of jcs_host, device and process internal state
    int reset();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    //                                                           S I G N A L    A P I 
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // Input/Output definitions:
    // - Output is defined as data leaving the network going to the outside world.
    // - Input is defined as data going from the outside world into the network.
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // JCS signals are accessable by three methods:
    //
    // Type Ordered Pool: Signals are acceess first by signal type, then by the order that they appear in config.
    //  - Signals are accessable by a vector of that type.
    //
    // Config Ordered Pool: Signals are accessed by the order they appear in config, regardless of type.
    //  - Signals may NOT be accessed by vector.
    //  - The user must ensure they are accessesing the correct signal type.
    //
    // Opstate Pool: Special pool containing only device opstates.
    //


    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //////_ Type Ordered Pool

    ////////////////////////////////////////////////////////////////////////////////////////
    // Returns the the number of input rates for the type ordered pool.
    // Type is not checked.
    // Safe to call outside real-time thread.
    int sig_input_rate_sz_rt(signal_type const type);

    ////////////////////////////////////////////////////////////////////////////////////////
    // Returns the number of output rates for the type ordered pool.
    // Type is not checked.
    // Safe to call outside real-time thread.
    int sig_output_rate_sz_rt(signal_type const type);


    ////////////////////////////////////////////////////////////////////////////////////////
    // Get the number of input signals for a given type pool.
    // Type is not checked.
    // Returns error if rate_idx is out of bounds.
    // Returns error if sz is NULL.
    // Result stored in sz.
    // Safe to call outside real-time thread.
    int sig_input_sz_rt(signal_type const type, unsigned int const rate_idx, unsigned int* sz);
    // Returns the number of input signals for a give type pool.
    // Type is not checked.
    // Returns 0 if rate_idx is out of bounds.
    // Safe to call outside real-time thread.
    int sig_input_sz_unsafe_rt(signal_type const type, unsigned int const rate_idx);

    ////////////////////////////////////////////////////////////////////////////////////////
    // Get the number of output signals for a given type pool.
    // Type is not checked.
    // Returns error if rate_idx is out of bounds.
    // Returns error if sz is NULL.
    // Result stored in sz.
    // Safe to call outside real-time thread.
    int sig_output_sz_rt(signal_type const type, unsigned int const rate_idx, unsigned int* sz);
    // Returns the number of output signals for a given type pool.
    // Type is not checked.
    // Returns 0 if rate_idx is out of bounds.
    // Safe to call outside real-time thread.
    int sig_output_sz_unsafe_rt(signal_type const type, unsigned int rate_idx);


    ////////////////////////////////////////////////////////////////////////////////////////
    // Returns false if any signal of that type pool vector is not valid.
    // Type is not checked.
    // Returns false if rate_idx is out of bounds.
    bool sig_output_is_valid_unsafe_rt(signal_type const type, unsigned int const rate_idx);
    // Returns false if the signal is not valid for the type ordered pool.
    // Type is not checked.
    // Returns false if rate_idx or idx is out of bounds.
    bool sig_output_is_valid_unsafe_rt(signal_type const type, unsigned int const rate_idx, unsigned int const idx);


    ////////////////////////////////////////////////////////////////////////////////////////
    // Returns true if any signal of that type pool vector are stale.
    // Type is not checked.
    // Returns true if rate_idx is out of bounds.
    bool sig_output_is_stale_unsafe_rt(signal_type const type, unsigned int const rate_idx);
    // Returns true if the signal is stale for the type ordered pool.
    // Type is not checked.
    // Returns true if rate_idx or idx is out of bounds.
    bool sig_output_is_stale_unsafe_rt(signal_type const type, unsigned int const rate_idx, unsigned int const idx);


    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Write a vector of inputs by type pool
    // Returns error if rate_idx is out of bounds.
    // Returns error if input vector in is not the same size as the given type pool vector.
    int sig_input_set_rt(unsigned int const rate_idx, std::vector<float> const& in);
    int sig_input_set_rt(unsigned int const rate_idx, std::vector<uint32_t> const& in);
    int sig_input_set_rt(unsigned int const rate_idx, std::vector<uint16_t> const& in);
    int sig_input_set_rt(unsigned int const rate_idx, std::vector<uint8_t> const& in);

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Write a single input by type pool
    // Returns error if rate_idx or idx is out of bounds.
    int sig_input_set_rt(unsigned int const rate_idx, unsigned int const idx, const float in);
    int sig_input_set_rt(unsigned int const rate_idx, unsigned int const idx, const uint32_t in);
    int sig_input_set_rt(unsigned int const rate_idx, unsigned int const idx, const uint16_t in);
    int sig_input_set_rt(unsigned int const rate_idx, unsigned int const idx, const uint8_t in);

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Read a vector of outputs by type pool.
    // Returns error if rate_idx is out of bounds.
    // Returns error if output vector out is NULL, or is not the same size as the given type pool vector.
    // Results stored in out,
    int sig_output_get_rt(unsigned int const rate_idx, std::vector<float>* out);
    int sig_output_get_rt(unsigned int const rate_idx, std::vector<uint32_t>* out);
    int sig_output_get_rt(unsigned int const rate_idx, std::vector<uint16_t>* out);
    int sig_output_get_rt(unsigned int const rate_idx, std::vector<uint8_t>* out);

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Read a single output by type pool.
    // Returns error if rate_idx or idx is out of bounds.
    // Returns error if out is NULL.
    // Results stored in out,
    int sig_output_get_rt(unsigned int const rate_idx, unsigned int const idx, float* out);
    int sig_output_get_rt(unsigned int const rate_idx, unsigned int const idx, uint32_t* out);
    int sig_output_get_rt(unsigned int const rate_idx, unsigned int const idx, uint16_t* out);
    int sig_output_get_rt(unsigned int const rate_idx, unsigned int const idx, uint8_t* out);


    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Get a vector of input signal node names from the given type pool.
    // Type is not checked.
    // Returns error if rate_idx is out of bounds.
    // Returns error if names is NULL, or if names is not the same size as the given type pool vector.
    // Result stored in names.
    int sig_input_node_name_get(signal_type const type, unsigned int const rate_idx, std::vector<std::string>* names);
    // Get a single input signal node name from the given type pool.
    // Type is not checked.
    // Returns error if rate_idx or idx is out of bounds.
    // Returns error if name is NULL.
    // Result stored in name.
    int sig_input_node_name_get(signal_type const type, unsigned int const rate_idx, unsigned int const idx, std::string* name);

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Get a vector of output signal node names from the given type pool.
    // Type is not checked.
    // Returns error if rate_idx is out of bounds.
    // Returns error if names is NULL, or if names is not the same size as the given type pool vector.
    // Result stored in names.
    int sig_output_node_name_get(signal_type const type, unsigned int const rate_idx, std::vector<std::string>* names);
    // Get a single output signal node name from the given type pool.
    // Type is not checked.
    // Returns error if rate_idx or idx is out of bounds.
    // Returns error if name is NULL.
    // Result stored in name.
    int sig_output_node_name_get(signal_type const type, unsigned int const rate_idx, unsigned int const idx, std::string* name);


    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Get a vector of input signal names from the given type pool.
    // Type is not checked.
    // Returns error if rate_idx is out of bounds.
    // Returns error if names is NULL, or if names is not the same size as the given type pool vector.
    // Result stored in names.
    int sig_input_name_get(signal_type const type, unsigned int const rate_idx, std::vector<std::string>* names);
    // Get a single input signal name from the given type pool.
    // Type is not checked.
    // Returns error if rate_idx or idx is out of bounds.
    // Returns error if name is NULL.
    // Result stored in name.
    int sig_input_name_get(signal_type const type, unsigned int const rate_idx, unsigned int const idx, std::string* name);

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Get a vector of output signal names from the given type pool.
    // Type is not checked.
    // Returns error if rate_idx is out of bounds.
    // Returns error if names is NULL, or if names is not the same size as the given type pool vector.
    // Result stored in names.
    int sig_output_name_get(signal_type const type, unsigned int const rate_idx, std::vector<std::string>* names);
    // Get a single output signal name from the given type pool.
    // Type is not checked.
    // Returns error if rate_idx or idx is out of bounds.
    // Returns error if name is NULL.
    // Result stored in name.
    int sig_output_name_get(signal_type const type, unsigned int const rate_idx, unsigned int const idx, std::string* name);


    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Get a vector of input signal units from the given type pool.
    // Type is not checked.
    // Returns error if rate_idx is out of bounds.
    // Returns error if units is NULL, or if units is not the same size as the given type pool vector.
    // Result stored in units.
    int sig_input_units_get(signal_type const type, unsigned int const rate_idx, std::vector<std::string>* units);
    // Get a single input signal unit from the given type pool.
    // Type is not checked.
    // Returns error if rate_idx or idx is out of bounds.
    // Returns error if units is NULL.
    // Result stored in units.
    int sig_input_units_get(signal_type const type, unsigned int const rate_idx, unsigned int const idx, std::string* units);

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Get a vector of output signal units from the given type pool.
    // Type is not checked.
    // Returns error if rate_idx is out of bounds.
    // Returns error if units is NULL, or if units is not the same size as the given type pool vector.
    // Result stored in units.
    int sig_output_units_get(signal_type const type, unsigned int const rate_idx, std::vector<std::string>* units);
    // Get a single output signal unit from the given type pool.
    // Type is not checked.
    // Returns error if rate_idx or idx is out of bounds.
    // Returns error if units is NULL.
    // Result stored in units.
    int sig_output_units_get(signal_type const type, unsigned int const rate_idx, unsigned int const idx, std::string* units);


    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Get the index of a single input signal by name from the given type pool.
    // Type is not checked.
    // Returns error if rate_idx is out of bounds.
    // Returns error if signal name is not found.
    // Returns error if idx is NULL.
    // Result stored in idx.
    int sig_input_index_get(signal_type const type, unsigned int const rate_idx, std::string const& name, unsigned int* idx);

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Get the index of a single output signal by name from the given type pool.
    // Type is not checked.
    // Returns error if rate_idx is out of bounds.
    // Returns error if signal name is not found.
    // Returns error if idx is NULL.
    // Result stored in idx.
    int sig_output_index_get(signal_type const type, unsigned int const rate_idx, std::string const& name, unsigned int* idx);



    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //////_ Config Ordered Pool

    ////////////////////////////////////////////////////////////////////////////////////////
    // Returns the number of input rates for the config ordered pool.
    // Safe to call outside real-time thread.
    int sig_input_rate_sz_rt();

    ////////////////////////////////////////////////////////////////////////////////////////
    // Returns the number of output rates for the config ordered pool..
    // Safe to call outside real-time thread.
    int sig_output_rate_sz_rt();


    ////////////////////////////////////////////////////////////////////////////////////////
    // Get the number of input signals for the config ordered pool.
    // Returns error if rate_idx is out of bounds.
    // Returns error if sz is NULL.
    // Result stored in sz.
    // Safe to call outside real-time thread.
    int sig_input_sz_rt(unsigned int const rate_idx, unsigned int* sz);
    // Returns the number of input signals for the config ordered pool.
    // Returns 0 if rate_idx is out of bounds.
    // Safe to call outside real-time thread.
    int sig_input_sz_unsafe_rt(unsigned int const rate_idx);

    ////////////////////////////////////////////////////////////////////////////////////////
    // Get the number of output signals for the config ordered pool.
    // Returns error if rate_idx is out of bounds.
    // Returns error if sz is NULL.
    // Result stored in sz.
    // Safe to call outside real-time thread.
    int sig_output_sz_rt(unsigned int const rate_idx, unsigned int* sz);
    // Returns the number of output signals for the config ordered pool.
    // Returns 0 if rate_idx is out of bounds.
    // Safe to call outside real-time thread.
    int sig_output_sz_unsafe_rt(unsigned int const rate_idx);


    ////////////////////////////////////////////////////////////////////////////////////////
    // Returns false if the signal is not valid for the config ordered pool.
    // Returns false if rate_idx or idx is out of bounds.
    bool sig_output_is_valid_unsafe_rt(unsigned int const rate_idx, unsigned int const idx);

    ////////////////////////////////////////////////////////////////////////////////////////
    // Returns true if the singal is stale for the config ordered pool.
    // Returns true if rate_idx or idx is out of bounds.
    bool sig_output_is_stale_unsafe_rt(unsigned int const rate_idx, unsigned int const idx);


    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Set input signals by the config ordered pool
    // Returns error if rate_idx or idx is out of bounds.
    int sig_input_cop_set_rt(unsigned int const rate_idx, unsigned int const idx, const float in);
    int sig_input_cop_set_rt(unsigned int const rate_idx, unsigned int const idx, const uint32_t in);
    int sig_input_cop_set_rt(unsigned int const rate_idx, unsigned int const idx, const uint16_t in);
    int sig_input_cop_set_rt(unsigned int const rate_idx, unsigned int const idx, const uint8_t in);

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Read output signals by the config ordered pool.
    // Returns error if rate_idx or idx is out of bounds.
    // Returns error if out is NULL.
    // Results stored in out,
    int sig_output_cop_get_rt(unsigned int const rate_idx, unsigned int const idx, float* out);
    int sig_output_cop_get_rt(unsigned int const rate_idx, unsigned int const idx, uint32_t* out);
    int sig_output_cop_get_rt(unsigned int const rate_idx, unsigned int const idx, uint16_t* out);
    int sig_output_cop_get_rt(unsigned int const rate_idx, unsigned int const idx, uint8_t* out);



    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Get a single input signal node name from the config ordered pool.
    // Returns error if rate_idx or idx is out of bounds.
    // Returns error if name is NULL.
    // Result stored in name.
    int sig_input_node_name_get(unsigned int const rate_idx, unsigned int const idx, std::string* name);

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Ge a single output signal node name from the config ordered pool.
    // Returns error if rate_idx or idx is out of bounds.
    // Returns error if name is NULL.
    // Result stored in name.
    int sig_output_node_name_get(unsigned int const rate_idx, unsigned int const idx, std::string* name);


    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Get a single input signal name from the config ordered pool.
    // Returns error if rate_idx or idx is out of bounds.
    // Returns error if name is NULL.
    // Result stored in name.
    int sig_input_name_get(unsigned int const rate_idx, unsigned int const idx, std::string* name);

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Get a single output signal name from the config ordered pool.
    // Returns error if rate_idx or idx is out of bounds.
    // Returns error if name is NULL.
    // Result stored in name.
    int sig_output_name_get(unsigned int const rate_idx, unsigned int const idx, std::string* name);


    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Get a single input signal unit from the config ordered pool.
    // Returns error if rate_idx or idx is out of bounds.
    // Returns error if units is NULL.
    // Result stored in units.
    int sig_input_units_get(unsigned int const rate_idx, unsigned int const idx, std::string* units);

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Get a single output signal unit from the config ordered pool.
    // Returns error if rate_idx or idx is out of bounds.
    // Returns error if units is NULL.
    // Result stored in units.
    int sig_output_units_get(unsigned int const rate_idx, unsigned int const idx, std::string* units);


    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Get the index of a single input signal by name from the config ordered pool.
    // Returns error if rate_idx is out of bounds.
    // Returns error if signal name is not found.
    // Returns error if idx is NULL.
    // Result stored in idx.
    int sig_input_index_get(unsigned int const rate_idx, std::string const& name, unsigned int* idx);

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Get the index of a single output signal by name from the config ordered pool.
    // Returns error if rate_idx is out of bounds.
    // Returns error if signal name is not found.
    // Returns error if idx is NULL.
    // Result stored in idx.
    int sig_output_index_get(unsigned int const rate_idx, std::string const& name, unsigned int* idx);



    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //////_ Opstate pool

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Returns the number of opstate signals.
    // Safe to call outside real-time thread.
    int sig_opstate_output_sz_rt();


    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Read opstate signals.
    // Returns error if output vector out is NULL, or is not the same size as returned by sig_opstate_output_sz().
    // Results stored in out,
    int sig_opstate_output_get_rt(std::vector<uint8_t>* out);
    // Returns error if idx is out of bounds.
    // Returns error if out is NULL.
    // Results stored in out,
    int sig_opstate_output_get_rt(unsigned int const idx, uint8_t* out);



    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Get a single opstate output signal node name.
    // Returns error if idx is out of bounds.
    // Returns error if name is NULL.
    // Result stored in name.
    int sig_opstate_output_node_name_get(unsigned int const idx, std::string* name);

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Get a single opstate output signal name.
    // Returns error if idx is out of bounds.
    // Returns error if name is NULL.
    // Result stored in name.
    int sig_opstate_output_name_get(unsigned int const idx, std::string* name);



    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //////_ Miscellaneous helpers

    ////////////////////////////////////////////////////////////////////////////////////////
    // Returns true if jcs_host has invalidated all signals of the rate rate_idx.
    // Returns true if rate_idx is out of bounds.
    bool sig_output_rate_is_invalidated_rt(unsigned int const rate_idx);

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Get the input signals limits (if configured) by signal name.
    // Returns error if signal name is not found.
    // Returns error if limit_h or limit_l is NULL.
    // Result stored in limit_h and limit_l.
    int sig_input_limits_get_by_name(std::string const& name, float* limit_h, float* limit_l);

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Signal type information. See jcs_host_types.h for signal_type definition.
    // Returns error if rate_idx or idx is out of bounds.
    // Returns error if type is NULL.
    // Results stored in type,
    int sig_get_input_type(unsigned int const rate_idx, unsigned int const idx, signal_type* type);
    int sig_get_output_type(unsigned int const rate_idx, unsigned int const idx, signal_type* type);




    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    //                                                           T O O L S   A P I 
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //////_ General tools
    // Get the base frequency in Hz
    unsigned int base_frequency_get();

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Device ID fetching tool. See jcs_host_types.h for dev_type and dev_id definition.
    // Returns error if jc_node_name not found.
    // Returns error if type or id are NULL.
    // Results stored in type and id.
    int node_device_id_get(std::string const& jc_node_name, std::string const& unknown_node_name, dev_type* type, dev_id* id);

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Write new firmware to node.
    // Returns error if node_name not found.
    // Returns error if fw_file_name not found.
    int write_new_firmware(std::string const& node_name, std::string const& fw_file_name);
    // Write new flashloader to node.
    // Returns error if node_name not found.
    // Returns error if fl_file_name not found.
    int write_new_flashloader(std::string const& node_name, std::string const& fl_file_name);

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //////_ Statistics
    // Return timing statistics for real-time system.
    statistics_timing statistics_timing_get();
    // Return health statistics for real-time system.
    statistics_health statistics_health_get();

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Print process timing information from the device perspective.
    void process_timing_print();
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Print all device error counters and overruns from the device perspective.
    void device_error_counts_print();
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Print all device estop reasons.
    // Returns error if device error search fails.
    int device_error_estop_print();
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Print number of overruns for each banner ID from the host perspective.
    void host_overrun_counts_print();
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Print all dev_jc ethercat transfer timings.
    // Returns error if jc timing search fails.
    int dev_jc_ethercat_timing_print();
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Access the device and process information tree
    std::vector<jcs_device>* external_info_tree_get();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    //                                                  D E V I C E   P A R A M E T E R   A P I 
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Write a command that takes no values or parameters
    // Returns error if node_name not found.
    // Returns error if command not found.
    int write_command(std::string const& node_name, std::string const& command);

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Write a float value.
    // Returns error if node_name not found.
    // Returns error if parameter not found.
    // Returns error if parameter is not a float parameter.
    int write_float(std::string const& node_name, std::string const& parameter, float value);
    // Returns error if value not the expected length.
    int write_float(std::string const& node_name, std::string const& parameter, std::vector<float> value);
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Read a float value.
    // Returns error if node_name not found.
    // Returns error if parameter not found.
    // Returns error if parameter is not a float parameter.
    // Returns error if value is NULL.
    int read_float(std::string const& node_name, std::string const& parameter, float* value);
    // Returns error if value not the expected length.
    int read_float(std::string const& node_name, std::string const& parameter, std::vector<float>* value);

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Write a uint32 value.
    // Returns error if node_name not found.
    // Returns error if parameter not found.
    // Returns error if parameter is not a uint32 parameter.
    int write_uint32(std::string const& node_name, std::string const& parameter, uint32_t value);
    // Returns error if value not the expected length.
    int write_uint32(std::string const& node_name, std::string const& parameter, std::vector<uint32_t> value);
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Read a uint32 value.
    // Returns error if node_name not found.
    // Returns error if parameter not found.
    // Returns error if parameter is not a uint32 parameter.
    // Returns error if value is NULL.
    int read_uint32(std::string const& node_name, std::string const& parameter, uint32_t* value);
    // Returns error if value not the expected length.
    int read_uint32(std::string const& node_name, std::string const& parameter, std::vector<uint32_t>* value);

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Write a uint16 value.
    // Returns error if node_name not found.
    // Returns error if parameter not found.
    // Returns error if parameter is not a uint16 parameter.
    int write_uint16(std::string const& node_name, std::string const& parameter, uint16_t value);
    // Returns error if value not the expected length.
    int write_uint16(std::string const& node_name, std::string const& parameter, std::vector<uint16_t> value);
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Read a uint16 value.
    // Returns error if node_name not found.
    // Returns error if parameter not found.
    // Returns error if parameter is not a uint16 parameter.
    // Returns error if value is NULL.
    int read_uint16(std::string const& node_name, std::string const& parameter, uint16_t* value);
    // Returns error if value not the expected length.
    int read_uint16(std::string const& node_name, std::string const& parameter, std::vector<uint16_t>* value);

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Write a uint8 value.
    // Returns error if node_name not found.
    // Returns error if parameter not found.
    // Returns error if parameter is not a uint8 parameter.
    int write_uint8(std::string const& node_name, std::string const& parameter, uint8_t value);
    // Returns error if value not the expected length.
    int write_uint8(std::string const& node_name, std::string const& parameter, std::vector<uint8_t> value);
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Read a uint8 value.
    // Returns error if node_name not found.
    // Returns error if parameter not found.
    // Returns error if parameter is not a uint8 parameter.
    // Returns error if value is NULL.
    int read_uint8(std::string const& node_name, std::string const& parameter, uint8_t* value);
    // Returns error if value not the expected length.
    int read_uint8(std::string const& node_name, std::string const& parameter, std::vector<uint8_t>* value);

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Write a boolean value.
    // Returns error if node_name not found.
    // Returns error if parameter not found.
    // Returns error if parameter is not a boolean parameter.
    int write_bool(std::string const& node_name, std::string const& parameter, bool value);
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Read a boolean value.
    // Returns error if node_name not found.
    // Returns error if parameter not found.
    // Returns error if parameter is not a boolean parameter.
    // Returns error if value is NULL.
    int read_bool(std::string const& node_name, std::string const& parameter, bool* value);

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Write an enumerated value.
    // Returns error if node_name not found.
    // Returns error if parameter not found.
    // Returns error if parameter is not an enumerated parameter.
    // Returns error if enum_entry is not found.
    int write_enum(std::string const& node_name, std::string const& parameter, std::string const& enum_entry);
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Read an enumerated value.
    // Returns error if node_name not found.
    // Returns error if parameter not found.
    // Returns error if parameter is not an enumerated parameter.
    // Returns error if enum_entry is not found.
    int read_enum(std::string const& node_name, std::string const& parameter, std::string* value);

private:
    class jcs_host_impl;
    std::unique_ptr<jcs_host_impl> impl_;
};

} // End namespace jcs
#endif
