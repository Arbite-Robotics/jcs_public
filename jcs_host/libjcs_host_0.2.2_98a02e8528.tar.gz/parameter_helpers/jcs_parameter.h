// Copyright (c) 2024 Arbite Robotics Pty Ltd
// https://arbite.io
//
#ifndef JCS_PARAMETER_H_
#define JCS_PARAMETER_H_

namespace jcs {

enum class parameter_type {
    p_none_t,
    p_bool_t,
    p_uint8_t,
    p_uint16_t,
    p_uint32_t,
    p_float32_t,
    p_enum8_t
};

struct parameter {
    std::string const name;
    parameter_type const type;
    int const length;
};

struct parameter_enum {
    std::string const name;
    std::vector<std::string> const enums;
};

} // End namespace jcs

#endif