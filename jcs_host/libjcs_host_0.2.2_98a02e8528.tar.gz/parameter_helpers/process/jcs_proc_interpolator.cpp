// Copyright (c) 2024 Arbite Robotics Pty Ltd
// https://arbite.io
//
#include "jcs_proc_interpolator.h"

// Parameters
std::vector<jcs::parameter> const jcs::node_parameter::proc_interpolator::parameters = {
    { "interpolator_type", parameter_type::p_enum8_t,   1 },
    { "x1_coeffs",         parameter_type::p_float32_t, 0 },
    { "x2_coeffs",         parameter_type::p_float32_t, 0 },
    { "f_x_coeffs",        parameter_type::p_float32_t, 0 },
    { "a_coeff",           parameter_type::p_float32_t, 1 },
    { "b_coeff",           parameter_type::p_float32_t, 1 },
};


// Oscilloscope sources
std::vector<std::string> const jcs::node_parameter::proc_interpolator::interpolator_type = {
    "linear_1d",
    "linear_2d",
};

// Note: Must go below enum vectors or they won't compile in!
std::vector<jcs::parameter_enum> const jcs::node_parameter::proc_interpolator::parameter_enums = {
    { "interpolator_type", jcs::node_parameter::proc_interpolator::interpolator_type }
};