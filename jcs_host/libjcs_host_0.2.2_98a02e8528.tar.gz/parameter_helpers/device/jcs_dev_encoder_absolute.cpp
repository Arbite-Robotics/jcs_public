// Copyright (c) 2024 Arbite Robotics Pty Ltd
// https://arbite.io
//
#include "jcs_dev_encoder_absolute.h"

// Parameters
std::vector<jcs::parameter> const jcs::node_parameter::dev_encoder_absolute::parameters = {
    { "th",                                   parameter_type::p_float32_t,  1 },
    { "thd",                                  parameter_type::p_float32_t,  1 },
    { "th_counts",                            parameter_type::p_uint16_t,   1 },
    { "rotor_position_zero",                  parameter_type::p_none_t,     0 },
    { "rotor_position_zero_offset",           parameter_type::p_float32_t,  1 },
    { "encoder_direction",                    parameter_type::p_bool_t,     1 },
    { "encoder_linearisation_coeffs",         parameter_type::p_float32_t, 64 },
    { "encoder_error_rate_limit",             parameter_type::p_float32_t,  1 },
    { "encoder_error_rate",                   parameter_type::p_float32_t,  1 },
    { "estimator_type",                       parameter_type::p_enum8_t,    1 },
    { "estimator_theta_passthrough",          parameter_type::p_bool_t,     1 },
    { "estimator_tracking_loop_kp",           parameter_type::p_float32_t,  1 },
    { "estimator_tracking_loop_ki",           parameter_type::p_float32_t,  1 },
    { "estimator_tracking_loop_bandwidth_hz", parameter_type::p_float32_t,  1 },
    { "estimator_kf_q_variance",              parameter_type::p_float32_t,  1 },
    { "an_0_gain",                            parameter_type::p_float32_t,  1 },
    { "an_0_offset",                          parameter_type::p_float32_t,  1 },
    { "an_0_limit_warning_h",                 parameter_type::p_float32_t,  1 },
    { "an_0_limit_warning_l",                 parameter_type::p_float32_t,  1 },
    { "an_0_limit_error_h",                   parameter_type::p_float32_t,  1 },
    { "an_0_limit_error_l",                   parameter_type::p_float32_t,  1 },
    { "an_0_filter_fc_hz",                    parameter_type::p_float32_t,  1 },
    { "an_0",                                 parameter_type::p_float32_t,  1 },
    { "an_0_f",                               parameter_type::p_float32_t,  1 },
    { "an_1_gain",                            parameter_type::p_float32_t,  1 },
    { "an_1_offset",                          parameter_type::p_float32_t,  1 },
    { "an_1_limit_warning_h",                 parameter_type::p_float32_t,  1 },
    { "an_1_limit_warning_l",                 parameter_type::p_float32_t,  1 },
    { "an_1_limit_error_h",                   parameter_type::p_float32_t,  1 },
    { "an_1_limit_error_l",                   parameter_type::p_float32_t,  1 },
    { "an_1_filter_fc_hz",                    parameter_type::p_float32_t,  1 },
    { "an_1",                                 parameter_type::p_float32_t,  1 },
    { "an_1_f",                               parameter_type::p_float32_t,  1 },
};

std::vector<std::string> const jcs::node_parameter::dev_encoder_absolute::estimator_type = {
    "tracking_loop",
    "kf"
};

// Note: Must go below enum vectors or they won't compile in!
std::vector<jcs::parameter_enum> const jcs::node_parameter::dev_encoder_absolute::parameter_enums = {
    { "estimator_type",                jcs::node_parameter::dev_encoder_absolute::estimator_type },
};