// Copyright (c) 2024 Arbite Robotics Pty Ltd
// https://arbite.io
//
#ifndef DEV_STRAIN_GAUGE_PARAMETER_H_
#define DEV_STRAIN_GAUGE_PARAMETER_H_

#include <vector>
#include <string>
#include "jcs_parameter.h"

namespace jcs {
namespace node_parameter {
namespace dev_strain_gauge {
    // Parameters
    extern std::vector<jcs::parameter> const parameters;

    // Parameter enums
    extern std::vector<jcs::parameter_enum> const parameter_enums;
    extern std::vector<std::string> const transform_type;
    extern std::vector<std::string> const temperature_source;
    extern std::vector<std::string> const adc_filter;
    extern std::vector<std::string> const adc_channel_gain;
    extern std::vector<std::string> const adc_channel_mux;
}
}
}
#endif