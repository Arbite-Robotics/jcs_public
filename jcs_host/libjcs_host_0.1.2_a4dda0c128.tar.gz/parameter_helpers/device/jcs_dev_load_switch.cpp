// Copyright (c) 2024 Arbite Robotics Pty Ltd
// https://arbite.io
//
#include "jcs_dev_load_switch.h"

// Parameters
std::vector<jcs::parameter> const jcs::node_parameter::dev_load_switch::parameters = {
    // Controller
    { "precharge_v_dc_out_in_diff",           parameter_type::p_float32_t, 1 },
    { "precharge_time_max_ms",                parameter_type::p_float32_t, 1 },
    { "bleed_v_dc_out_min",                   parameter_type::p_float32_t, 1 },
    { "bleed_time_max_ms",                    parameter_type::p_float32_t, 1 },
    { "switch_on",                            parameter_type::p_none_t,    0 },
    { "switch_off",                           parameter_type::p_none_t,    0 },
    { "switch_off_immediate",                 parameter_type::p_none_t,    0 },
    { "switch_is_on",                         parameter_type::p_bool_t,    1 },
    { "switch_is_off",                        parameter_type::p_bool_t,    1 },
    // Temperature sensor
    { "temperature_0_f",                      parameter_type::p_float32_t, 1 },
    { "temperature_0_limit_warning_h",        parameter_type::p_float32_t, 1 },
    { "temperature_0_limit_warning_l",        parameter_type::p_float32_t, 1 },
    { "temperature_0_limit_error_h",          parameter_type::p_float32_t, 1 },
    { "temperature_0_limit_error_l",          parameter_type::p_float32_t, 1 },
    // DC bus in voltage and filter
    { "v_dc_in_f",                            parameter_type::p_float32_t, 1 },
    { "v_dc_in_filter_fc_hz",                 parameter_type::p_float32_t, 1 },
    { "v_dc_in_limit_warning_h",              parameter_type::p_float32_t, 1 },
    { "v_dc_in_limit_warning_l",              parameter_type::p_float32_t, 1 },
    { "v_dc_in_limit_error_h",                parameter_type::p_float32_t, 1 },
    { "v_dc_in_limit_error_l",                parameter_type::p_float32_t, 1 },
    // DC bus in voltage and filter
    { "v_dc_out_f",                           parameter_type::p_float32_t, 1 },
    { "v_dc_out_filter_fc_hz",                parameter_type::p_float32_t, 1 },
    { "v_dc_out_limit_warning_h",             parameter_type::p_float32_t, 1 },
    { "v_dc_out_limit_warning_l",             parameter_type::p_float32_t, 1 },
    { "v_dc_out_limit_error_h",               parameter_type::p_float32_t, 1 },
    { "v_dc_out_limit_error_l",               parameter_type::p_float32_t, 1 },
    // DC bus in current and filter
    { "i_dc_out_f",                           parameter_type::p_float32_t, 1 },
    { "i_dc_out_filter_fc_hz",                parameter_type::p_float32_t, 1 },
    { "i_dc_out_limit_warning_h",             parameter_type::p_float32_t, 1 },
    { "i_dc_out_limit_warning_l",             parameter_type::p_float32_t, 1 },
    { "i_dc_out_limit_error_h",               parameter_type::p_float32_t, 1 },
    { "i_dc_out_limit_error_l",               parameter_type::p_float32_t, 1 },
    { "oscilloscope_sample_rate_hz",          parameter_type::p_uint32_t,  1 },
    { "oscilloscope_force_start",             parameter_type::p_none_t,    0 },
    { "oscilloscope_wait_trigger",            parameter_type::p_none_t,    0 },
    { "oscilloscope_is_done",                 parameter_type::p_bool_t,    1 },
    { "oscilloscope_stop",                    parameter_type::p_none_t,    0 },
    { "oscilloscope_trigger_source",          parameter_type::p_enum8_t,   1 },
    { "oscilloscope_trigger_level",           parameter_type::p_float32_t, 1 },
    { "oscilloscope_trigger_config",          parameter_type::p_enum8_t,   1 },
    { "oscilloscope_trigger_buffer_position", parameter_type::p_uint32_t,  1 },
    { "oscilloscope_channel_0_source",        parameter_type::p_enum8_t,   1 },
    { "oscilloscope_channel_0",               parameter_type::p_float32_t, 768 },
    { "oscilloscope_channel_1_source",        parameter_type::p_enum8_t,   1 },
    { "oscilloscope_channel_1",               parameter_type::p_float32_t, 768 },
    { "oscilloscope_channel_2_source",        parameter_type::p_enum8_t,   1 },
    { "oscilloscope_channel_2",               parameter_type::p_float32_t, 768 },
    { "oscilloscope_channel_3_source",        parameter_type::p_enum8_t,   1 },
    { "oscilloscope_channel_3",               parameter_type::p_float32_t, 768 }
};

// Oscilloscope sources
std::vector<std::string> const jcs::node_parameter::dev_load_switch::oscilloscope_sources = {
    "ls_osc_chan_none",
    "ls_osc_v_dc_in",
    "ls_osc_v_dc_out",
    "ls_osc_i_dc_out",
    "ls_osc_t_0",
};

// Oscilloscope trigger options
std::vector<std::string> const jcs::node_parameter::dev_load_switch::oscilloscope_trigger_config = {
    "osc_trigger_rising",
    "osc_trigger_falling"
};

// Note: Must go below enum vectors or they won't compile in!
std::vector<jcs::parameter_enum> const jcs::node_parameter::dev_load_switch::parameter_enums = {
    { "oscilloscope_trigger_source",     jcs::node_parameter::dev_load_switch::oscilloscope_sources },
    { "oscilloscope_channel_0_source",   jcs::node_parameter::dev_load_switch::oscilloscope_sources },
    { "oscilloscope_channel_1_source",   jcs::node_parameter::dev_load_switch::oscilloscope_sources },
    { "oscilloscope_channel_2_source",   jcs::node_parameter::dev_load_switch::oscilloscope_sources },
    { "oscilloscope_channel_3_source",   jcs::node_parameter::dev_load_switch::oscilloscope_sources },
    { "oscilloscope_trigger_config",     jcs::node_parameter::dev_load_switch::oscilloscope_trigger_config }
};

// Number of oscilloscope channels
int const jcs::node_parameter::dev_load_switch::oscilloscope_n_channels = 4;
// Maximum oscilloscope sample length
int const jcs::node_parameter::dev_load_switch::oscilloscope_sample_length = 768;
// Default sample rate
int const jcs::node_parameter::dev_load_switch::oscilloscope_sample_rate_hz = 10000;