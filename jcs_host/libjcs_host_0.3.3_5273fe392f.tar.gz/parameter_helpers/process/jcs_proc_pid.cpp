// Copyright (c) 2024 Arbite Robotics Pty Ltd
// https://arbite.io
//
#include "jcs_proc_pid.h"

// Parameters
std::vector<jcs::parameter> const jcs::node_parameter::proc_pid::parameters = {
    { "proc_pid_kp",                            parameter_type::p_float32_t,  1 },
    { "proc_pid_ki",                            parameter_type::p_float32_t,  1 },
    { "proc_pid_kd",                            parameter_type::p_float32_t,  1 },
    { "proc_pid_kff",                           parameter_type::p_float32_t,  1 },
    { "proc_pid_limit_out_h",                   parameter_type::p_float32_t,  1 },
    { "proc_pid_limit_out_l",                   parameter_type::p_float32_t,  1 },
    { "proc_pid_rate_limit_rising",             parameter_type::p_float32_t,  1 },
    { "proc_pid_rate_limit_falling",            parameter_type::p_float32_t,  1 },
    { "proc_pid_startup_rate_limit",            parameter_type::p_float32_t,  1 },
    { "proc_pid_derivative_tau",                parameter_type::p_float32_t,  1 },
    { "proc_pid_use_derivative_on_measurement", parameter_type::p_bool_t,     1 },
    { "proc_pid_is_rotational_error",           parameter_type::p_bool_t,     1 }
};
