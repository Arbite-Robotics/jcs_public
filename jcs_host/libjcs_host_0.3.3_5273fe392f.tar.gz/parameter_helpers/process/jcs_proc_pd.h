// Copyright (c) 2024 Arbite Robotics Pty Ltd
// https://arbite.io
//
#ifndef PROC_PD_PARAMETER_H_
#define PROC_PD_PARAMETER_H_

#include <vector>
#include <string>
#include "jcs_parameter.h"

namespace jcs {
namespace node_parameter {
namespace proc_pd {
    // Parameters
    extern std::vector<jcs::parameter> const parameters;
}
}
}
#endif