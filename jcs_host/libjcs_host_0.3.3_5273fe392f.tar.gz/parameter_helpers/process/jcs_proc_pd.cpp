// Copyright (c) 2024 Arbite Robotics Pty Ltd
// https://arbite.io
//
#include "jcs_proc_pd.h"

// Parameters
std::vector<jcs::parameter> const jcs::node_parameter::proc_pd::parameters = {
    { "proc_pd_kp",                    parameter_type::p_float32_t,  1 },
    { "proc_pd_kd",                    parameter_type::p_float32_t,  1 },
    { "proc_pd_kff",                   parameter_type::p_float32_t,  1 },
    { "proc_pd_limit_out_h",           parameter_type::p_float32_t,  1 },
    { "proc_pd_limit_out_l",           parameter_type::p_float32_t,  1 },
    { "proc_pd_rate_limit_rising",     parameter_type::p_float32_t,  1 },
    { "proc_pd_rate_limit_falling",    parameter_type::p_float32_t,  1 },
    { "proc_pd_startup_rate_limit",    parameter_type::p_float32_t,  1 },
    { "proc_pd_p_is_rotational_error", parameter_type::p_bool_t,     1 },
    { "proc_pd_d_is_rotational_error", parameter_type::p_bool_t,     1 },
};
