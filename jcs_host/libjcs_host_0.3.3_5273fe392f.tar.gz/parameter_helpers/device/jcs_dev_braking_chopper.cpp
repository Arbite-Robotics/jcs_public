// Copyright (c) 2024 Arbite Robotics Pty Ltd
// https://arbite.io
//
#include "jcs_dev_braking_chopper.h"

// Parameters
std::vector<jcs::parameter> const jcs::node_parameter::dev_braking_chopper::parameters = {
    // JCS control / config
    { "stop",                                     parameter_type::p_none_t,     0 },
    { "start",                                    parameter_type::p_none_t,     0 },
    { "reset",                                    parameter_type::p_none_t,     0 },
    { "op_state",                                 parameter_type::p_uint8_t,    1 },
    { "network_estop_config",                     parameter_type::p_enum8_t,    1 },
    // Temperature
    { "temperature_0_limit_warning_h",            parameter_type::p_float32_t, 1 },
    { "temperature_0_limit_warning_l",            parameter_type::p_float32_t, 1 },
    { "temperature_0_limit_error_h",              parameter_type::p_float32_t, 1 },
    { "temperature_0_limit_error_l",              parameter_type::p_float32_t, 1 },
    { "temperature_0_error_on_warning",           parameter_type::p_bool_t,    1 },
    { "temperature_0_f",                          parameter_type::p_float32_t, 1 },
    // External analog
    { "an_0_gain",                                parameter_type::p_float32_t, 1 },
    { "an_0_offset",                              parameter_type::p_float32_t, 1 },
    { "an_0_limit_warning_h",                     parameter_type::p_float32_t, 1 },
    { "an_0_limit_warning_l",                     parameter_type::p_float32_t, 1 },
    { "an_0_limit_error_h",                       parameter_type::p_float32_t, 1 },
    { "an_0_limit_error_l",                       parameter_type::p_float32_t, 1 },
    { "an_0_limit_hysteresis",                    parameter_type::p_float32_t, 1 },
    { "an_0_filter_fc_hz",                        parameter_type::p_float32_t, 1 },
    { "an_0_error_on_warning",                    parameter_type::p_bool_t,    1 },
    { "an_0",                                     parameter_type::p_float32_t, 1 },
    { "an_0_f",                                   parameter_type::p_float32_t, 1 },
    // DC bus limits and filter
    { "v_dc_filter_fc_hz",                        parameter_type::p_float32_t, 1 },
    { "v_dc_filter_slow_fc_hz",                   parameter_type::p_float32_t, 1 },
    { "v_dc_limit_warning_h",                     parameter_type::p_float32_t, 1 },
    { "v_dc_limit_warning_l",                     parameter_type::p_float32_t, 1 },
    { "v_dc_limit_error_h",                       parameter_type::p_float32_t, 1 },
    { "v_dc_limit_error_l",                       parameter_type::p_float32_t, 1 },
    { "v_dc",                                     parameter_type::p_float32_t, 1 },
    { "v_dc_f",                                   parameter_type::p_float32_t, 1 },
    { "v_dc_slow_f",                              parameter_type::p_float32_t, 1 },
    // Controller
    { "controller_type",                          parameter_type::p_enum8_t,   1 },
    { "controller_resistor_ohms",                 parameter_type::p_float32_t, 1 },
    { "controller_start",                         parameter_type::p_none_t,    0 },
    { "controller_stop",                          parameter_type::p_none_t,    0 },
    { "controller_is_running",                    parameter_type::p_bool_t,    1 },
    { "duty",                                     parameter_type::p_float32_t, 1 },
    { "power_dumped_w",                           parameter_type::p_float32_t, 1 },
    { "controller_duty_filter_fc_hz",             parameter_type::p_float32_t, 1 },
    { "controller_power_filter_fc_hz",            parameter_type::p_float32_t, 1 },
    { "controller_v_dc_hysteresis_h",             parameter_type::p_float32_t, 1 },
    { "controller_v_dc_hysteresis_l",             parameter_type::p_float32_t, 1 },
    { "controller_v_dc_reference_source",         parameter_type::p_enum8_t,   1 },
    { "controller_v_dc_reference_const",          parameter_type::p_float32_t, 1 },
    { "controller_v_dc_temp_penalty_source",      parameter_type::p_enum8_t,   1 },
    { "controller_v_dc_temp_penalty_t_l",         parameter_type::p_float32_t, 1 },
    { "controller_v_dc_temp_penalty_t_h",         parameter_type::p_float32_t, 1 },
    { "controller_v_dc_temp_penalty_v_delta",     parameter_type::p_float32_t, 1 },
    // Oscilloscope
    { "oscilloscope_sample_rate_hz",              parameter_type::p_uint32_t,  1 },
    { "oscilloscope_force_start",                 parameter_type::p_none_t,    0 },
    { "oscilloscope_wait_trigger",                parameter_type::p_none_t,    0 },
    { "oscilloscope_is_done",                     parameter_type::p_bool_t,    1 },
    { "oscilloscope_stop",                        parameter_type::p_none_t,    0 },
    { "oscilloscope_trigger_source",              parameter_type::p_enum8_t,   1 },
    { "oscilloscope_trigger_level",               parameter_type::p_float32_t, 1 },
    { "oscilloscope_trigger_config",              parameter_type::p_enum8_t,   1 },
    { "oscilloscope_trigger_buffer_position",     parameter_type::p_uint32_t,  1 },
    { "oscilloscope_channel_0_source",            parameter_type::p_enum8_t,   1 },
    { "oscilloscope_channel_0",                   parameter_type::p_float32_t, 768 },
    { "oscilloscope_channel_1_source",            parameter_type::p_enum8_t,   1 },
    { "oscilloscope_channel_1",                   parameter_type::p_float32_t, 768 },
    { "oscilloscope_channel_2_source",            parameter_type::p_enum8_t,   1 },
    { "oscilloscope_channel_2",                   parameter_type::p_float32_t, 768 },
    { "oscilloscope_channel_3_source",            parameter_type::p_enum8_t,   1 },
    { "oscilloscope_channel_3",                   parameter_type::p_float32_t, 768 },
    // Timing
    { "ctl_timing_step_max_us",                   parameter_type::p_uint32_t,  1 },
    { "ctl_timing_step_ave_us",                   parameter_type::p_uint32_t,  1 },
    { "ctl_timing_interval_us",                   parameter_type::p_uint32_t,  1 },
    { "ctl_timing_overrun_count",                 parameter_type::p_uint32_t,  1 },
};

std::vector<std::string> const jcs::node_parameter::dev_braking_chopper::network_estop_config = {
    "estop_force_shutdown",
    "estop_safe_controller",
    "estop_stop",
    "estop_do_nothing",
};

std::vector<std::string> const jcs::node_parameter::dev_braking_chopper::controller_type = {
    "controller_none",
    "dc_chopper",
    "hysteresis",
};

std::vector<std::string> const jcs::node_parameter::dev_braking_chopper::controller_v_dc_reference_source = {
    "v_dc_reference_slow_filter",
    "v_dc_reference_constant"
};

std::vector<std::string> const jcs::node_parameter::dev_braking_chopper::controller_v_dc_temp_penalty_source = {
    "v_dc_temp_penalty_disabled",
    "v_dc_temp_penalty_temp_0",
    "v_dc_temp_penalty_an_0"
};

// Oscilloscope sources
std::vector<std::string> const jcs::node_parameter::dev_braking_chopper::oscilloscope_sources = {
    "bc_osc_chan_none",
    "bc_osc_v_dc_in",
    "bc_osc_v_dc_slow",
    "bc_osc_controller_duty",
    "bc_osc_p_dumped",
    "bc_osc_t_0",
    "bc_osc_v_an_0",
};

// Oscilloscope trigger options
std::vector<std::string> const jcs::node_parameter::dev_braking_chopper::oscilloscope_trigger_config = {
    "osc_trigger_rising",
    "osc_trigger_falling"
};

// Note: Must go below enum vectors or they won't compile in!
std::vector<jcs::parameter_enum> const jcs::node_parameter::dev_braking_chopper::parameter_enums = {
    { "network_estop_config",                jcs::node_parameter::dev_braking_chopper::network_estop_config },
    { "controller_type",                     jcs::node_parameter::dev_braking_chopper::controller_type },
    { "controller_v_dc_reference_source",    jcs::node_parameter::dev_braking_chopper::controller_v_dc_reference_source },
    { "controller_v_dc_temp_penalty_source", jcs::node_parameter::dev_braking_chopper::controller_v_dc_temp_penalty_source },
    { "oscilloscope_trigger_source",         jcs::node_parameter::dev_braking_chopper::oscilloscope_sources },
    { "oscilloscope_channel_0_source",       jcs::node_parameter::dev_braking_chopper::oscilloscope_sources },
    { "oscilloscope_channel_1_source",       jcs::node_parameter::dev_braking_chopper::oscilloscope_sources },
    { "oscilloscope_channel_2_source",       jcs::node_parameter::dev_braking_chopper::oscilloscope_sources },
    { "oscilloscope_channel_3_source",       jcs::node_parameter::dev_braking_chopper::oscilloscope_sources },
    { "oscilloscope_trigger_config",         jcs::node_parameter::dev_braking_chopper::oscilloscope_trigger_config }
};

// Number of oscilloscope channels
int const jcs::node_parameter::dev_braking_chopper::oscilloscope_n_channels = 4;
// Maximum oscilloscope sample length
int const jcs::node_parameter::dev_braking_chopper::oscilloscope_sample_length = 768;
// Default sample rate
int const jcs::node_parameter::dev_braking_chopper::oscilloscope_sample_rate_hz = 10000;