// Copyright (c) 2024 Arbite Robotics Pty Ltd
// https://arbite.io
//
#ifndef DEV_BRAKING_CHOPPER_PARAMETER_H_
#define DEV_BRAKING_CHOPPER_PARAMETER_H_

#include <vector>
#include <string>
#include "jcs_parameter.h"

namespace jcs {
namespace node_parameter {
namespace dev_braking_chopper {
    // Parameters
    extern std::vector<jcs::parameter> const parameters;

    // Parameter enums
    extern std::vector<jcs::parameter_enum> const parameter_enums;
    extern std::vector<std::string> const network_estop_config;
    extern std::vector<std::string> const controller_type;
    extern std::vector<std::string> const controller_v_dc_reference_source;
    extern std::vector<std::string> const controller_v_dc_temp_penalty_source;

    // Oscilloscope sources
    extern std::vector<std::string> const oscilloscope_sources;
    // Oscilloscope trigger options
    extern std::vector<std::string> const oscilloscope_trigger_config;
    // Number of oscilloscope channels
    extern int const oscilloscope_n_channels;
    // Maximum oscilloscope sample length
    extern int const oscilloscope_sample_length;
    // Default sample rate
    extern int const oscilloscope_sample_rate_hz;
}
}
}
#endif