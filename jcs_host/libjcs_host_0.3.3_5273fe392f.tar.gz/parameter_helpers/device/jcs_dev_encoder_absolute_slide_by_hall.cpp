// Copyright (c) 2024 Arbite Robotics Pty Ltd
// https://arbite.io
//
#include "jcs_dev_encoder_absolute_slide_by_hall.h"

// Parameters
std::vector<jcs::parameter> const jcs::node_parameter::dev_encoder_absolute_slide_by_hall::parameters = {
    // JCS control / config
    { "stop",                                 parameter_type::p_none_t,    0 },
    { "start",                                parameter_type::p_none_t,    0 },
    { "reset",                                parameter_type::p_none_t,    0 },
    { "op_state",                             parameter_type::p_uint8_t,   1 },
    // State
    { "x",                                   parameter_type::p_float32_t,  1 },
    { "xd",                                  parameter_type::p_float32_t,  1 },
    // Encoder
    { "encoder_direction",                   parameter_type::p_bool_t,     1 },
    { "position_zero",                       parameter_type::p_none_t,     0 },
    { "position_zero_offset",                parameter_type::p_float32_t,  1 },
    // Estimator
    { "estimator_x_passthrough",             parameter_type::p_bool_t,     1 },
    { "estimator_q_variance",                parameter_type::p_float32_t,  1 },
    // Internal
    { "hall_tC_max",                         parameter_type::p_float32_t,  1 },
    { "hall_tC_min",                         parameter_type::p_float32_t,  1 },
    { "hall_0_gain",                         parameter_type::p_float32_t,  1 },
    { "hall_0_offset",                       parameter_type::p_float32_t,  1 },
    { "hall_0_filter_fc_hz",                 parameter_type::p_float32_t,  1 },
    { "hall_0_t_poly",                       parameter_type::p_float32_t,  4 },
    { "hall_1_gain",                         parameter_type::p_float32_t,  1 },
    { "hall_1_offset",                       parameter_type::p_float32_t,  1 },
    { "hall_1_filter_fc_hz",                 parameter_type::p_float32_t,  1 },
    { "hall_1_t_poly",                       parameter_type::p_float32_t,  4 },
    { "hall_2_gain",                         parameter_type::p_float32_t,  1 },
    { "hall_2_offset",                       parameter_type::p_float32_t,  1 },
    { "hall_2_filter_fc_hz",                 parameter_type::p_float32_t,  1 },
    { "hall_2_t_poly",                       parameter_type::p_float32_t,  4 },
    { "slide_by_hall_0_coefficients",        parameter_type::p_float32_t, 64 },
    { "slide_by_hall_1_coefficients",        parameter_type::p_float32_t, 64 },
    { "slide_by_hall_2_coefficients",        parameter_type::p_float32_t, 64 },
    { "slide_by_hall_valid_pos_thresh_0",    parameter_type::p_float32_t,  2 },
    { "slide_by_hall_valid_pos_thresh_n",    parameter_type::p_float32_t,  2 },
};

