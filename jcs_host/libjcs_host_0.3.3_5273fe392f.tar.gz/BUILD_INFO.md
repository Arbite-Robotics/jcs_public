# Build information

libjcs_host is built against:

libyaml-cpp-dev Version: 0.8.0+dfsg-6build1
g++ (Ubuntu 13.3.0-6ubuntu2~24.04) 13.3.0
