// Copyright (c) 2024 Arbite Robotics Pty Ltd
// https://arbite.io
//
#ifndef DEV_ENCODER_ABSOLUTE_PARAMETER_H_
#define DEV_ENCODER_ABSOLUTE_PARAMETER_H_

#include <vector>
#include <string>
#include "jcs_parameter.h"

namespace jcs {
namespace node_parameter {
namespace dev_encoder_absolute {
    // Parameters
    extern std::vector<jcs::parameter> const parameters;

    // Parameter enums
    extern std::vector<jcs::parameter_enum> const parameter_enums;
    extern std::vector<std::string> const estimator_type;
}
}
}
#endif