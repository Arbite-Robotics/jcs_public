// Copyright (c) 2024 Arbite Robotics Pty Ltd
// https://arbite.io
//
#include "jcs_dev_encoder_relative.h"

// Parameters
std::vector<jcs::parameter> const jcs::node_parameter::dev_encoder_relative::parameters = {
    // JCS control / config
    { "stop",                                 parameter_type::p_none_t,    0 },
    { "start",                                parameter_type::p_none_t,    0 },
    { "reset",                                parameter_type::p_none_t,    0 },
    { "op_state",                             parameter_type::p_uint8_t,   1 },
    // State
    { "x_m",                                  parameter_type::p_float32_t,  1 },
    { "xd_m",                                 parameter_type::p_float32_t,  1 },
    { "x_m_counts",                           parameter_type::p_float32_t,  1 },
    { "x_m_encoder",                          parameter_type::p_float32_t,  1 },
    // Encoder
    { "encoder_position_zero",                parameter_type::p_none_t,     0 },
    { "encoder_position_zero_offset",         parameter_type::p_float32_t,  1 },
    { "encoder_accumulator_reset",            parameter_type::p_none_t,     0 },
    { "encoder_type",                         parameter_type::p_enum8_t,    1 },
    { "encoder_direction",                    parameter_type::p_bool_t,     1 },
    { "encoder_scale",                        parameter_type::p_float32_t,  1 },
    { "encoder_error_rate_limit",             parameter_type::p_float32_t,  1 },
    { "encoder_error_rate",                   parameter_type::p_float32_t,  1 },
    // Estimator
    { "estimator_type",                       parameter_type::p_enum8_t,    1 },
    { "estimator_x_passthrough",              parameter_type::p_bool_t,     1 },
    { "estimator_tracking_loop_kp",           parameter_type::p_float32_t,  1 },
    { "estimator_tracking_loop_ki",           parameter_type::p_float32_t,  1 },
    { "estimator_tracking_loop_bandwidth_hz", parameter_type::p_float32_t,  1 },
    { "estimator_kf_q_variance",              parameter_type::p_float32_t,  1 },
    { "estimator_kf_r",                       parameter_type::p_float32_t,  1 },
    { "estimator_kf_P_initial",               parameter_type::p_float32_t,  4 },
    // External analog
    { "an_0_gain",                            parameter_type::p_float32_t,  1 },
    { "an_0_offset",                          parameter_type::p_float32_t,  1 },
    { "an_0_limit_warning_h",                 parameter_type::p_float32_t,  1 },
    { "an_0_limit_warning_l",                 parameter_type::p_float32_t,  1 },
    { "an_0_limit_error_h",                   parameter_type::p_float32_t,  1 },
    { "an_0_limit_error_l",                   parameter_type::p_float32_t,  1 },
    { "an_0_limit_hysteresis",                parameter_type::p_float32_t,  1 },
    { "an_0_filter_fc_hz",                    parameter_type::p_float32_t,  1 },
    { "an_0_error_on_warning",                parameter_type::p_bool_t,     1 },
    { "an_0",                                 parameter_type::p_float32_t,  1 },
    { "an_0_f",                               parameter_type::p_float32_t,  1 },
};

std::vector<std::string> const jcs::node_parameter::dev_encoder_relative::encoder_type = {
    "encoder_rotary",
    "encoder_linear",
};

std::vector<std::string> const jcs::node_parameter::dev_encoder_relative::estimator_type = {
    "estimator_none",
    "estimator_tracking_loop",
    "estimator_kalman_filter",
};

// Note: Must go below enum vectors or they won't compile in!
std::vector<jcs::parameter_enum> const jcs::node_parameter::dev_encoder_relative::parameter_enums = {
    { "encoder_type",   jcs::node_parameter::dev_encoder_relative::encoder_type },
    { "estimator_type", jcs::node_parameter::dev_encoder_relative::estimator_type }
};