// Copyright (c) 2024 Arbite Robotics Pty Ltd
// https://arbite.io
//
#ifndef DEV_ENCODER_ABSOLUTE_SLIDEBYHALL_PARAMETER_H_
#define DEV_ENCODER_ABSOLUTE_SLIDEBYHALL_PARAMETER_H_

#include <vector>
#include <string>
#include "jcs_parameter.h"

namespace jcs {
namespace node_parameter {
namespace dev_encoder_absolute_slide_by_hall {
    // Parameters
    extern std::vector<jcs::parameter> const parameters;
}
}
}
#endif