// Copyright (c) 2024 Arbite Robotics Pty Ltd
// https://arbite.io
//
#ifndef DEV_MC_PARAMETER_H_
#define DEV_MC_PARAMETER_H_

#include <vector>
#include <string>
#include "jcs_parameter.h"

namespace jcs {
namespace node_parameter {
namespace dev_motor_controller {
    // Parameters
    extern std::vector<jcs::parameter> const parameters;

    // Parameter enums
    extern std::vector<jcs::parameter_enum> const parameter_enums;
    extern std::vector<std::string> const network_estop_config;
    extern std::vector<std::string> const controller_mode;
    extern std::vector<std::string> const controller_state;
    extern std::vector<std::string> const commutation_source;
    extern std::vector<std::string> const dq_filter;
    extern std::vector<std::string> const encoder_type;
    extern std::vector<std::string> const encoder_spi_frequency;
    extern std::vector<std::string> const encoder_spi_polarity;
    extern std::vector<std::string> const encoder_spi_phase;
    extern std::vector<std::string> const encoder_spi_transfer_size;
    extern std::vector<std::string> const estimator_type;
    extern std::vector<std::string> const measurement_test_axis;

    // Oscilloscope sources
    extern std::vector<std::string> const oscilloscope_sources;
    // Oscilloscope trigger options
    extern std::vector<std::string> const oscilloscope_trigger_config;

    // Number of oscilloscope channels
    extern int const oscilloscope_n_channels;
    // Maximum oscilloscope sample length
    extern int const oscilloscope_sample_length;
    // Default sample rate
    extern int const oscilloscope_sample_rate_hz;
}
}
}
#endif