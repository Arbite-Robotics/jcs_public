/*//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//                                                            _   ____ ____  ______________ 
//                                                           / \ | __ \ _  \|_\__ __/  _  / 
//                                                          /   \|   _/  __/| | | | |   \/  
//                                                         / /\  \ \ \| __ \| | | | |  _/\  
//                                                        /_//____\|\_\____/|_| |_| |_____\ 
//                                                       --–-––-–––R O B O T I C S–––-––-–--
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// jcs_host_types.h - Joint Control System (JCS) dev_host types
//
// Copyright (c) 2024 Arbite Robotics Pty Ltd
// https://arbite.io
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////*/
#ifndef JCS_HOST_TYPES_H_
#define JCS_HOST_TYPES_H_

#include <string>
#include <vector>

namespace jcs {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////_ JCS major device types
//
// - Do not edit this list
// - This list may grow as more devices are added
// - Enums may not be contiguous!
enum dev_type {
    dev_host                = 0x0000,
    dev_joint_controller    = 0x0001,
    dev_motor_controller    = 0x0003,
    dev_encoder_absolute    = 0x0004,
    dev_braking_chopper     = 0x0005,
    dev_encoder_relative    = 0x0006,
    dev_load_switch         = 0x0007,
    dev_imu                 = 0x0008,
    dev_thermal             = 0x0009,
    dev_strain_gauge        = 0x000B,
    dev_brake_clutch        = 0x000C,
    dev_analog              = 0x000D,
};
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////_ JCS device node types
//
// - Do not edit this list
// - This list may grow as more devices are added
// 
// JCS device nodes match the major device types list except where device variants are present.
// For example, different absolute encoders require different signals and parameters.
// Choose the device node based on the type specified in the device documentation.
//
// The list is presented as commented strings. Copy the list as required for your application.
/*
"dev_host"
"dev_joint_controller"
"dev_motor_controller"
"dev_encoder_absolute"
"dev_encoder_absolute_slide_by_hall"
"dev_encoder_absolute_ic_mu"
"dev_braking_chopper"
"dev_encoder_relative"
"dev_load_switch"
"dev_imu"
"dev_thermal"
"dev_thermal_simple"
"dev_strain_gauge"
"dev_brake_clutch"
"dev_analog"
*/

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////_ JCS process types
//
// - Do not edit this list
// - This list may grow as more processes are added
enum proc_type {
    proc_test_echo,
    proc_pi,
    proc_pid,
    proc_solver,
    proc_pd,
    proc_test_flood,
    proc_interpolator,
    proc_transform
};
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////_ JCS process node types
//
// - Do not edit this list
// - This list may grow as more devices are added
// 
// JCS process nodes match the process types list except where device variants are present.
// Choose the process node based on the type specified in the process documentation.
//
// The list is presented as commented strings. Copy the list as required for your application.
/*
"proc_test_echo"
"proc_pi"
"proc_pid"
"proc_solver"
"proc_pd"
"proc_test_flood"
"proc_interpolator"
"proc_transform"
*/

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////_ JCS synchronous system signal types
enum signal_type {
    float32_s,
    // float16_s, // Not supported yet
    uint32_s,
    uint16_s,
    uint8_s,
};

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////_ JCS public return types
enum {
    RET_OK                      = 0,            // General returned ok
    RET_ERROR                   = 1,            // General returned error
    RET_NRDY                    = 2,            // General return not ready
    RET_TIMEOUT                 = 2,            // General return timed out
    RET_TPRT_DROPPED            = 2,            // Dropped packet or frame. Possible to continue
    RET_NOT_FOUND               = 2,            // General return not found
};

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////_ Device ID structure
struct dev_id {
    unsigned int id[3];

    bool operator==(dev_id const& rhs) {
        return  this->id[0] == rhs.id[0] &&
                this->id[1] == rhs.id[1] &&
                this->id[2] == rhs.id[2];
    }
};

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////_ dev_host Statistic structures
// step_rt function statistics
struct statistics_timing {
    long int    total_cycle_time_ns;            // Total time spent in step_rt function
    long int    data_exchange_time_ns;          // Time spent in step_rt function doing data exchange with devices
};

// jcs_host health statistics
struct statistics_overrun {
    unsigned int overrun_count;                 // Number of overruns since jcs_host initialisation
    long int     last_timestamp_ns;             // Last overrun timestamp
    double       counts_percent;                // Overrun counts as a percentage of tick rate
};

struct statistics_variance {
    unsigned int overrun_count;                 // Number of overruns since jcs_host initialisation
    long int     last_timestamp_ns;             // Last overrun timestamp
    double       counts_percent;                // Overrun counts as a percentage of tick rate
    double       mean;                          // Running mean
    double       variance;                      // Running variance
};

struct statistics_health {
    // Overrun statistics for base rate
    statistics_overrun  pending_sequences_fullrate;
    // Overrun statistics for first sub rate
    statistics_overrun  pending_sequences_subrate_0;
    // Overrun statistics for second sub rate
    statistics_overrun  pending_sequences_subrate_1;
    // Overrun statistics for third sub rate
    statistics_overrun  pending_sequences_subrate_2;
    // Overrun statistics for transport
    statistics_overrun  transport;
    // Real-time thread overrun and variance statistics
    // Mean and variance reflect the accruacy of the real-time thread cycle period
    statistics_variance thread_offset;
};

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////_ JCS device and process information structure
//
// jcs_host will build a vector of available devices and processes that are attached each device.
// Access this structure via external_info_tree_get();
struct jcs_process {
    std::string name;           // Process name
    std::string node_type;      // Process node type (see JCS process node types)
    proc_type   type;           // Process type (see JCS process types)
};

struct jcs_device {
    std::string name;           // Device name
    std::string node_type;      // Device node type (see JCS device node types)
    dev_type    type;           // Device major type (see JCS major device types)
    dev_id      id;             // Device hardware ID
    std::vector<jcs_process> procs;     // Processes instanciated on this device
};

} // End namespace jcs
#endif
