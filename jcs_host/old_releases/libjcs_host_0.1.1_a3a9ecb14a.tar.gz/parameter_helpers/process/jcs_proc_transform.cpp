// Copyright (c) 2024 Arbite Robotics Pty Ltd
// https://arbite.io
//
#include "jcs_proc_transform.h"

// Parameters
std::vector<jcs::parameter> const jcs::node_parameter::proc_transform::parameters = {
    { "transform_type",  parameter_type::p_enum8_t,   1 },
    { "a_coeff",         parameter_type::p_float32_t, 1 },
    { "b_coeff",         parameter_type::p_float32_t, 1 },
    { "A22_coeffs",      parameter_type::p_float32_t, 4 },
    { "b21_coeffs",      parameter_type::p_float32_t, 2 },
};


// Oscilloscope sources
std::vector<std::string> const jcs::node_parameter::proc_transform::transform_type = {
    "type_1x1",
    "type_2x2",
};

// Note: Must go below enum vectors or they won't compile in!
std::vector<jcs::parameter_enum> const jcs::node_parameter::proc_transform::parameter_enums = {
    { "transform_type", jcs::node_parameter::proc_transform::transform_type }
};