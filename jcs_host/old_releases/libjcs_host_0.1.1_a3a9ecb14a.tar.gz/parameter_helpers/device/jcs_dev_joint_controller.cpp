// Copyright (c) 2024 Arbite Robotics Pty Ltd
// https://arbite.io
//
#include "jcs_dev_joint_controller.h"

// Parameters
std::vector<jcs::parameter> const jcs::node_parameter::dev_joint_controller::parameters = {
    { "an_0_gain",                             parameter_type::p_float32_t,  1 },
    { "an_0_offset",                           parameter_type::p_float32_t,  1 },
    { "an_0_limit_warning_h",                  parameter_type::p_float32_t,  1 },
    { "an_0_limit_warning_l",                  parameter_type::p_float32_t,  1 },
    { "an_0_limit_error_h",                    parameter_type::p_float32_t,  1 },
    { "an_0_limit_error_l",                    parameter_type::p_float32_t,  1 },
    { "an_0_filter_fc_hz",                     parameter_type::p_float32_t,  1 },
    { "an_0",                                  parameter_type::p_float32_t,  1 },
    { "an_0_f",                                parameter_type::p_float32_t,  1 },
    { "an_1_gain",                             parameter_type::p_float32_t,  1 },
    { "an_1_offset",                           parameter_type::p_float32_t,  1 },
    { "an_1_limit_warning_h",                  parameter_type::p_float32_t,  1 },
    { "an_1_limit_warning_l",                  parameter_type::p_float32_t,  1 },
    { "an_1_limit_error_h",                    parameter_type::p_float32_t,  1 },
    { "an_1_limit_error_l",                    parameter_type::p_float32_t,  1 },
    { "an_1_filter_fc_hz",                     parameter_type::p_float32_t,  1 },
    { "an_1",                                  parameter_type::p_float32_t,  1 },
    { "an_1_f",                                parameter_type::p_float32_t,  1 },
    { "an_2_gain",                             parameter_type::p_float32_t,  1 },
    { "an_2_offset",                           parameter_type::p_float32_t,  1 },
    { "an_2_limit_warning_h",                  parameter_type::p_float32_t,  1 },
    { "an_2_limit_warning_l",                  parameter_type::p_float32_t,  1 },
    { "an_2_limit_error_h",                    parameter_type::p_float32_t,  1 },
    { "an_2_limit_error_l",                    parameter_type::p_float32_t,  1 },
    { "an_2_filter_fc_hz",                     parameter_type::p_float32_t,  1 },
    { "an_2",                                  parameter_type::p_float32_t,  1 },
    { "an_2_f",                                parameter_type::p_float32_t,  1 },
    { "an_3_gain",                             parameter_type::p_float32_t,  1 },
    { "an_3_offset",                           parameter_type::p_float32_t,  1 },
    { "an_3_limit_warning_h",                  parameter_type::p_float32_t,  1 },
    { "an_3_limit_warning_l",                  parameter_type::p_float32_t,  1 },
    { "an_3_limit_error_h",                    parameter_type::p_float32_t,  1 },
    { "an_3_limit_error_l",                    parameter_type::p_float32_t,  1 },
    { "an_3_filter_fc_hz",                     parameter_type::p_float32_t,  1 },
    { "an_3",                                  parameter_type::p_float32_t,  1 },
    { "an_3_f",                                parameter_type::p_float32_t,  1 },
    { "encoder_0_type",                        parameter_type::p_enum8_t,    1 },
    { "encoder_0_position_zero",               parameter_type::p_none_t,     0 },
    { "encoder_0_position_offset",             parameter_type::p_float32_t,  1 },
    { "encoder_0_direction",                   parameter_type::p_bool_t,     1 },
    { "encoder_0_theta_bypass",                parameter_type::p_bool_t,     1 },
    { "encoder_0_theta_bypass_direction",      parameter_type::p_bool_t,     1 },
    { "encoder_0_linearisation_coeffs",        parameter_type::p_float32_t,  64 },
    { "encoder_0_error_rate_limit",            parameter_type::p_float32_t,  1 },
    { "th_m_0",                                parameter_type::p_float32_t,  1 },
    { "w_m_0",                                 parameter_type::p_float32_t,  1 },
    { "th_m_counts_0",                         parameter_type::p_uint32_t,   1 },
    { "th_m_encoder_0",                        parameter_type::p_float32_t,  1 },
    { "encoder_0_spi_frequency",               parameter_type::p_enum8_t,    1 },
    { "encoder_0_spi_phase",                   parameter_type::p_enum8_t,    1 },
    { "encoder_0_spi_polarity",                parameter_type::p_enum8_t,    1 },
    { "encoder_0_spi_transfer_size",           parameter_type::p_enum8_t,    1 },
    { "encoder_0_spi_using_chip_select",       parameter_type::p_bool_t,     1 },
    { "encoder_0_spi_command",                 parameter_type::p_uint8_t,    0 },
    { "encoder_0_spi_position_mask",           parameter_type::p_uint8_t,    0 },
    { "encoder_0_spi_position_bits",           parameter_type::p_uint8_t,    1 },
    { "encoder_0_spi_masked_position_shift",   parameter_type::p_uint8_t,    1 },
    { "encoder_0_spi_masked_flag_shift",       parameter_type::p_uint8_t,    1 },
    { "encoder_0_spi_flag_mask",               parameter_type::p_uint8_t,    0 },
    { "encoder_0_incremental_cpr",             parameter_type::p_uint32_t,   1 },
    { "encoder_0_as5047p_last_rx",             parameter_type::p_uint16_t,   1 },
    { "estimator_0_type",                      parameter_type::p_enum8_t,    1 },
    { "estimator_0_theta_passthrough",         parameter_type::p_bool_t,     1 },
    { "estimator_0_tracking_loop_kp",          parameter_type::p_float32_t,  1 },
    { "estimator_0_tracking_loop_ki",          parameter_type::p_float32_t,  1 },
    { "estimator_0_tracking_loop_bandwidth_hz",parameter_type::p_float32_t,  1 },
    { "estimator_0_kalman_q",                  parameter_type::p_float32_t,  1 },
    { "estimator_0_kalman_r_w",                parameter_type::p_float32_t,  1 },
    { "estimator_0_kalman_r_th",               parameter_type::p_float32_t,  1 },
    { "estimator_0_P_initial",                 parameter_type::p_float32_t,  4 },
    { "encoder_1_type",                        parameter_type::p_enum8_t,    1 },
    { "encoder_1_position_zero",               parameter_type::p_none_t,     0 },
    { "encoder_1_position_offset",             parameter_type::p_float32_t,  1 },
    { "encoder_1_direction",                   parameter_type::p_bool_t,     1 },
    { "encoder_1_theta_bypass",                parameter_type::p_bool_t,     1 },
    { "encoder_1_theta_bypass_direction",      parameter_type::p_bool_t,     1 },
    { "encoder_1_linearisation_coeffs",        parameter_type::p_float32_t,  64 },
    { "encoder_1_error_rate_limit",            parameter_type::p_float32_t,  1 },
    { "th_m_1",                                parameter_type::p_float32_t,  1 },
    { "w_m_1",                                 parameter_type::p_float32_t,  1 },
    { "th_m_counts_1",                         parameter_type::p_uint32_t,   1 },
    { "th_m_encoder_1",                        parameter_type::p_float32_t,  1 },
    { "encoder_1_spi_frequency",               parameter_type::p_enum8_t,    1 },
    { "encoder_1_spi_phase",                   parameter_type::p_enum8_t,    1 },
    { "encoder_1_spi_polarity",                parameter_type::p_enum8_t,    1 },
    { "encoder_1_spi_transfer_size",           parameter_type::p_enum8_t,    1 },
    { "encoder_1_spi_using_chip_select",       parameter_type::p_bool_t,     1 },
    { "encoder_1_spi_command",                 parameter_type::p_uint8_t,    0 },
    { "encoder_1_spi_position_mask",           parameter_type::p_uint8_t,    0 },
    { "encoder_1_spi_position_bits",           parameter_type::p_uint8_t,    1 },
    { "encoder_1_spi_masked_position_shift",   parameter_type::p_uint8_t,    1 },
    { "encoder_1_spi_masked_flag_shift",       parameter_type::p_uint8_t,    1 },
    { "encoder_1_spi_flag_mask",               parameter_type::p_uint8_t,    0 },
    { "encoder_1_incremental_cpr",             parameter_type::p_uint32_t,   1 },
    { "encoder_1_as5047p_last_rx",             parameter_type::p_uint16_t,   1 },
    { "estimator_1_type",                      parameter_type::p_enum8_t,    1 },
    { "estimator_1_theta_passthrough",         parameter_type::p_bool_t,     1 },
    { "estimator_1_tracking_loop_kp",          parameter_type::p_float32_t,  1 },
    { "estimator_1_tracking_loop_ki",          parameter_type::p_float32_t,  1 },
    { "estimator_1_tracking_loop_bandwidth_hz",parameter_type::p_float32_t,  1 },
    { "estimator_1_kalman_q",                  parameter_type::p_float32_t,  1 },
    { "estimator_1_kalman_r_w",                parameter_type::p_float32_t,  1 },
    { "estimator_1_kalman_r_th",               parameter_type::p_float32_t,  1 },
    { "estimator_1_P_initial",                 parameter_type::p_float32_t,  4 },
    { "ecat_timing_sync_to_tx_ave_us",         parameter_type::p_uint32_t,   1 },
    { "ecat_timing_sync_to_tx_max_us",         parameter_type::p_uint32_t,   1 },
    { "ecat_timing_sync_to_rx_ave_us",         parameter_type::p_uint32_t,   1 },
    { "ecat_timing_sync_to_rx_max_us",         parameter_type::p_uint32_t,   1 },
    { "ecat_timing_tx_ave_us",                 parameter_type::p_uint32_t,   1 },
    { "ecat_timing_tx_max_us",                 parameter_type::p_uint32_t,   1 },
    { "ecat_timing_rx_ave_us",                 parameter_type::p_uint32_t,   1 },
    { "ecat_timing_rx_max_us",                 parameter_type::p_uint32_t,   1 },
};

std::vector<std::string> const jcs::node_parameter::dev_joint_controller::encoder_type = {
    "encoder_none",
    "jcs_as5047p",
    "incremental",
    "jcs_network",
    "spi"
};

std::vector<std::string> const jcs::node_parameter::dev_joint_controller::encoder_spi_frequency = {
    "frequency_fpclk_on_2",
    "frequency_fpclk_on_4",
    "frequency_fpclk_on_8",
    "frequency_fpclk_on_16",
    "frequency_fpclk_on_32",
    "frequency_fpclk_on_64",
    "frequency_fpclk_on_128",
    "frequency_fpclk_on_256"
};

std::vector<std::string> const jcs::node_parameter::dev_joint_controller::encoder_spi_polarity = {
    "first_edge",
    "second_edge"
};

std::vector<std::string> const jcs::node_parameter::dev_joint_controller::encoder_spi_phase = {
    "idle_low",
    "idle_high"
};

std::vector<std::string> const jcs::node_parameter::dev_joint_controller::encoder_spi_transfer_size = {
    "num_bits_8",
    "num_bits_7",
    "num_bits_6",
    "num_bits_5",
    "num_bits_4"
};

std::vector<std::string> const jcs::node_parameter::dev_joint_controller::estimator_type = {
    "estimator_none",
    "tracking_loop",
    "kf"
};

// Note: Must go below enum vectors or they won't compile in!
std::vector<jcs::parameter_enum> const jcs::node_parameter::dev_joint_controller::parameter_enums = {
    { "encoder_0_type",                jcs::node_parameter::dev_joint_controller::encoder_type },
    { "encoder_0_spi_frequency",       jcs::node_parameter::dev_joint_controller::encoder_spi_frequency },
    { "encoder_0_spi_polarity",        jcs::node_parameter::dev_joint_controller::encoder_spi_polarity },
    { "encoder_0_spi_phase",           jcs::node_parameter::dev_joint_controller::encoder_spi_phase },
    { "encoder_0_spi_transfer_size",   jcs::node_parameter::dev_joint_controller::encoder_spi_transfer_size },
    { "estimator_0_type",              jcs::node_parameter::dev_joint_controller::estimator_type },
    { "encoder_1_type",                jcs::node_parameter::dev_joint_controller::encoder_type },
    { "encoder_1_spi_frequency",       jcs::node_parameter::dev_joint_controller::encoder_spi_frequency },
    { "encoder_1_spi_polarity",        jcs::node_parameter::dev_joint_controller::encoder_spi_polarity },
    { "encoder_1_spi_phase",           jcs::node_parameter::dev_joint_controller::encoder_spi_phase },
    { "encoder_1_spi_transfer_size",   jcs::node_parameter::dev_joint_controller::encoder_spi_transfer_size },
    { "estimator_1_type",              jcs::node_parameter::dev_joint_controller::estimator_type },
};