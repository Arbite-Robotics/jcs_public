// Copyright (c) 2024 Arbite Robotics Pty Ltd
// https://arbite.io
//
#include "jcs_dev_thermal_simple.h"

// Parameters
std::vector<jcs::parameter> const jcs::node_parameter::dev_thermal_simple::parameters = {
    { "i_dc_0_limit_warning_h",                      parameter_type::p_float32_t, 1 },
    { "i_dc_0_limit_warning_l",                      parameter_type::p_float32_t, 1 },
    { "i_dc_0_limit_error_h",                        parameter_type::p_float32_t, 1 },
    { "i_dc_0_limit_error_l",                        parameter_type::p_float32_t, 1 },
    { "i_dc_0_filter_fc_hz",                         parameter_type::p_float32_t, 1 },
    { "i_dc_1_limit_warning_h",                      parameter_type::p_float32_t, 1 },
    { "i_dc_1_limit_warning_l",                      parameter_type::p_float32_t, 1 },
    { "i_dc_1_limit_error_h",                        parameter_type::p_float32_t, 1 },
    { "i_dc_1_limit_error_l",                        parameter_type::p_float32_t, 1 },
    { "i_dc_1_filter_fc_hz",                         parameter_type::p_float32_t, 1 },
    { "low_controller_0_type",                       parameter_type::p_enum8_t,   1 },
    { "low_controller_0_kp",                         parameter_type::p_float32_t, 1 },
    { "low_controller_0_ki",                         parameter_type::p_float32_t, 1 },
    { "low_controller_0_speed_warning_h",            parameter_type::p_float32_t, 1 },
    { "low_controller_0_speed_warning_l",            parameter_type::p_float32_t, 1 },
    { "low_controller_1_type",                       parameter_type::p_enum8_t,   1 },
    { "low_controller_1_kp",                         parameter_type::p_float32_t, 1 },
    { "low_controller_1_ki",                         parameter_type::p_float32_t, 1 },
    { "low_controller_1_speed_warning_h",            parameter_type::p_float32_t, 1 },
    { "low_controller_1_speed_warning_l",            parameter_type::p_float32_t, 1 },
    { "high_controller_0_type",                      parameter_type::p_enum8_t,   1 },
    { "high_controller_0_linear_map_output_coeffs",  parameter_type::p_float32_t, 4 },
    { "high_controller_0_linear_map_input_0_coeffs", parameter_type::p_float32_t, 4 },
    { "high_controller_0_linear_map_input_1_coeffs", parameter_type::p_float32_t, 4 },
    { "high_controller_0_linear_map_input_2_coeffs", parameter_type::p_float32_t, 4 },
    { "high_controller_0_linear_map_input_3_coeffs", parameter_type::p_float32_t, 4 },
    { "high_controller_1_type",                      parameter_type::p_enum8_t,   1 },
    { "high_controller_1_linear_map_output_coeffs",  parameter_type::p_float32_t, 4 },
    { "high_controller_1_linear_map_input_0_coeffs", parameter_type::p_float32_t, 4 },
    { "high_controller_1_linear_map_input_1_coeffs", parameter_type::p_float32_t, 4 },
    { "high_controller_1_linear_map_input_2_coeffs", parameter_type::p_float32_t, 4 },
    { "high_controller_1_linear_map_input_3_coeffs", parameter_type::p_float32_t, 4 }
};

std::vector<std::string> const jcs::node_parameter::dev_thermal_simple::low_controller_type = {
    "internal_speed",
    "external_feedback",
    "direct",
    "current"
};

std::vector<std::string> const jcs::node_parameter::dev_thermal_simple::high_controller_type = {
    "disabled",
    "linear_map"
};

// Note: Must go below enum vectors or they won't compile in!
std::vector<jcs::parameter_enum> const jcs::node_parameter::dev_thermal_simple::parameter_enums = {
    { "low_controller_0_type", jcs::node_parameter::dev_thermal_simple::low_controller_type },
    { "low_controller_1_type", jcs::node_parameter::dev_thermal_simple::low_controller_type },
    { "high_controller_0_type", jcs::node_parameter::dev_thermal_simple::high_controller_type },
    { "high_controller_1_type", jcs::node_parameter::dev_thermal_simple::high_controller_type },
};