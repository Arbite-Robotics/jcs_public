// Copyright (c) 2024 Arbite Robotics Pty Ltd
// https://arbite.io
//
#include "jcs_dev_braking_chopper.h"

// Parameters
std::vector<jcs::parameter> const jcs::node_parameter::dev_braking_chopper::parameters = {
    { "temperature_0_limit_warning_h",            parameter_type::p_float32_t, 1 },
    { "temperature_0_limit_warning_l",            parameter_type::p_float32_t, 1 },
    { "temperature_0_limit_error_h",              parameter_type::p_float32_t, 1 },
    { "temperature_0_limit_error_l",              parameter_type::p_float32_t, 1 },
    { "an_0_gain",                                parameter_type::p_float32_t, 1 },
    { "an_0_offset",                              parameter_type::p_float32_t, 1 },
    { "an_0_limit_warning_h",                     parameter_type::p_float32_t, 1 },
    { "an_0_limit_warning_l",                     parameter_type::p_float32_t, 1 },
    { "an_0_limit_error_h",                       parameter_type::p_float32_t, 1 },
    { "an_0_limit_error_l",                       parameter_type::p_float32_t, 1 },
    { "an_0_filter_fc_hz",                        parameter_type::p_float32_t, 1 },
    { "v_dc_filter_fc_hz",                        parameter_type::p_float32_t, 1 },
    { "v_dc_filter_slow_fc_hz",                   parameter_type::p_float32_t, 1 },
    { "v_dc_limit_warning_h",                     parameter_type::p_float32_t, 1 },
    { "v_dc_limit_warning_l",                     parameter_type::p_float32_t, 1 },
    { "v_dc_limit_error_h",                       parameter_type::p_float32_t, 1 },
    { "v_dc_limit_error_l",                       parameter_type::p_float32_t, 1 },
    { "controller_type",                          parameter_type::p_enum8_t,   1 },
    { "controller_resistor_ohms",                 parameter_type::p_float32_t, 1 },
    { "controller_v_dc_hysteresis_h",             parameter_type::p_float32_t, 1 },
    { "controller_v_dc_hysteresis_l",             parameter_type::p_float32_t, 1 },
    { "controller_v_dc_delta_max",                parameter_type::p_float32_t, 1 },
    { "controller_v_dc_reference_source",         parameter_type::p_enum8_t,   1 },
    { "controller_v_dc_reference_const",          parameter_type::p_float32_t, 1 },
    { "controller_v_dc_temp_penalty_source",      parameter_type::p_enum8_t,   1 },
    { "controller_v_dc_temp_penalty_t_l",         parameter_type::p_float32_t, 1 },
    { "controller_v_dc_temp_penalty_t_h",         parameter_type::p_float32_t, 1 },
    { "controller_v_dc_temp_penalty_v_delta",     parameter_type::p_float32_t, 1 },
    { "controller_hysteresis_duty_fc_hz",         parameter_type::p_float32_t, 1 }
};

std::vector<std::string> const jcs::node_parameter::dev_braking_chopper::controller_type = {
    "controller_none",
    "dc_chopper",
    "hysteresis",
};

std::vector<std::string> const jcs::node_parameter::dev_braking_chopper::controller_v_dc_reference_source = {
    "v_dc_temp_penalty_disabled",
    "v_dc_temp_penalty_temp_0",
    "v_dc_temp_penalty_an_0"
};

std::vector<std::string> const jcs::node_parameter::dev_braking_chopper::controller_v_dc_temp_penalty_source = {
    "v_dc_reference_slow_filter",
    "v_dc_reference_constant"
};

// Note: Must go below enum vectors or they won't compile in!
std::vector<jcs::parameter_enum> const jcs::node_parameter::dev_braking_chopper::parameter_enums = {
    { "controller_type",                     jcs::node_parameter::dev_braking_chopper::controller_type },
    { "controller_v_dc_reference_source",    jcs::node_parameter::dev_braking_chopper::controller_v_dc_reference_source },
    { "controller_v_dc_temp_penalty_source", jcs::node_parameter::dev_braking_chopper::controller_v_dc_temp_penalty_source },
};