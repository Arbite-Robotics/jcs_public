// Copyright (c) 2024 Arbite Robotics Pty Ltd
// https://arbite.io
//
#include "jcs_dev_encoder_relative.h"

// Parameters
std::vector<jcs::parameter> const jcs::node_parameter::dev_encoder_relative::parameters = {
    { "x",                                  parameter_type::p_float32_t,  1 },
    { "xd",                                 parameter_type::p_float32_t,  1 },
    { "x_counts",                           parameter_type::p_float32_t,  1 },
    { "encoder_position_zero",              parameter_type::p_none_t,     0 },
    { "encoder_direction",                  parameter_type::p_bool_t,     1 },
    { "encoder_error_rate_limit",           parameter_type::p_float32_t,  1 },
    { "estimator_type",                     parameter_type::p_enum8_t,    1 },
    { "estimator_x_passthrough",            parameter_type::p_bool_t,     1 },
    { "estimator_linear_scale",             parameter_type::p_float32_t,  1 },
    { "estimator_linear_q_variance",        parameter_type::p_float32_t,  1 },
    { "estimator_linear_r",                 parameter_type::p_float32_t,  1 },
    { "estimator_linear_P_initial",         parameter_type::p_float32_t,  4 },
    { "estimator_rotary_cpr",               parameter_type::p_uint32_t,   1 },
    { "estimator_rotary_q_variance",        parameter_type::p_float32_t,  1 },
    { "estimator_rotary_r",                 parameter_type::p_float32_t,  1 },
    { "estimator_rotary_P_initial",         parameter_type::p_float32_t,  4 },
    { "an_0_gain",                          parameter_type::p_float32_t,  1 },
    { "an_0_offset",                        parameter_type::p_float32_t,  1 },
    { "an_0_limit_warning_h",               parameter_type::p_float32_t,  1 },
    { "an_0_limit_warning_l",               parameter_type::p_float32_t,  1 },
    { "an_0_limit_error_h",                 parameter_type::p_float32_t,  1 },
    { "an_0_limit_error_l",                 parameter_type::p_float32_t,  1 },
    { "an_0_filter_fc_hz",                  parameter_type::p_float32_t,  1 }
};

std::vector<std::string> const jcs::node_parameter::dev_encoder_relative::estimator_type = {
    "estimator_none",
    "kf_linear",
    "kf_rotational",
};


// Note: Must go below enum vectors or they won't compile in!
std::vector<jcs::parameter_enum> const jcs::node_parameter::dev_encoder_relative::parameter_enums = {
    { "estimator_type", jcs::node_parameter::dev_encoder_relative::estimator_type }
};