# Arbite Robotics jcs_host

jcs_host is the interface between Arbite Robotics Joint Control System hardware and your higher level robotics software.

jcs_host is provided as a C++ library for Linux Operating systems.


## Build information

libjcs_host is built against:

g++ 9.4.0
libyaml-cpp0.7


## JCS Documentation

For JCS documentation please see:
https://jcsdoc.arbite.io


---

# Contact Information

Arbite Robotics
https://arbite.io

email: contact@arbite.io

