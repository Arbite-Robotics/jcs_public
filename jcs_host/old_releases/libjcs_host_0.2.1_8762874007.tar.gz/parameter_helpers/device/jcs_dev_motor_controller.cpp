// Copyright (c) 2024 Arbite Robotics Pty Ltd
// https://arbite.io
//
#include "jcs_dev_motor_controller.h"

// Parameters
std::vector<jcs::parameter> const jcs::node_parameter::dev_motor_controller::parameters = {
    { "controller_mode",                        parameter_type::p_enum8_t,    1 },
    { "controller_start",                       parameter_type::p_none_t,     0 },
    { "controller_stop",                        parameter_type::p_none_t,     0 },
    { "controller_is_running",                  parameter_type::p_bool_t,     1 },
    { "controller_is_error",                    parameter_type::p_bool_t,     1 },
    { "controller_is_standby",                  parameter_type::p_bool_t,     1 },
    { "controller_state",                       parameter_type::p_enum8_t,    1 },
    { "is_aligned",                             parameter_type::p_bool_t,     1 },
    { "align_in_dwell",                         parameter_type::p_bool_t,     0 },
    { "i_d_alignment",                          parameter_type::p_float32_t,  1 },
    { "i_d_alignment_ramp_time_ms",             parameter_type::p_float32_t,  1 },
    { "ctl_timing_step_max_us",                 parameter_type::p_uint32_t,   1 },
    { "ctl_timing_step_ave_us",                 parameter_type::p_uint32_t,   1 },
    { "ctl_timing_interval_us",                 parameter_type::p_uint32_t,   1 },
    { "ctl_timing_overrun_count",               parameter_type::p_uint32_t,   1 },
    { "i_d_kp",                                 parameter_type::p_float32_t,  1 },
    { "i_d_ki",                                 parameter_type::p_float32_t,  1 },
    { "i_d_out_lim_h",                          parameter_type::p_float32_t,  1 },
    { "i_d_out_lim_l",                          parameter_type::p_float32_t,  1 },
    { "i_d",                                    parameter_type::p_float32_t,  1 },
    { "i_q_kp",                                 parameter_type::p_float32_t,  1 },
    { "i_q_ki",                                 parameter_type::p_float32_t,  1 },
    { "i_q_out_lim_h",                          parameter_type::p_float32_t,  1 },
    { "i_q_out_lim_l",                          parameter_type::p_float32_t,  1 },
    { "i_q",                                    parameter_type::p_float32_t,  1 },
    { "using_vdq_decouple",                     parameter_type::p_bool_t,     1 },
    { "v_dc",                                   parameter_type::p_float32_t,  1 },
    { "i_a",                                    parameter_type::p_float32_t,  1 },
    { "i_b",                                    parameter_type::p_float32_t,  1 },
    { "i_c",                                    parameter_type::p_float32_t,  1 },
    { "i_mot",                                  parameter_type::p_float32_t,  1 },
    { "i_bus",                                  parameter_type::p_float32_t,  1 },
    { "i_mot_abs",                              parameter_type::p_float32_t,  1 },
    { "v_d",                                    parameter_type::p_float32_t,  1 },
    { "v_q",                                    parameter_type::p_float32_t,  1 },
    { "temperature_ave",                        parameter_type::p_float32_t,  1 },
    { "motor_Rd",                               parameter_type::p_float32_t,  1 },
    { "motor_Rq",                               parameter_type::p_float32_t,  1 },
    { "motor_Ld",                               parameter_type::p_float32_t,  1 },
    { "motor_Lq",                               parameter_type::p_float32_t,  1 },
    { "motor_Ym",                               parameter_type::p_float32_t,  1 },
    { "motor_pp",                               parameter_type::p_uint32_t,   1 },
    { "motor_phase_swap",                       parameter_type::p_bool_t,     1 },
    { "motor_Kt",                               parameter_type::p_float32_t,  1 },
    { "temperature_penalty_limit_h",            parameter_type::p_float32_t,  1 },
    { "temperature_penalty_limit_l",            parameter_type::p_float32_t,  1 },
    { "temperature_penalty_scale_l",            parameter_type::p_float32_t,  1 },
    { "temperature_penalty_ctrl_is_clamped",    parameter_type::p_bool_t,     1 },
    { "temperature_penalty_using_ext_an",       parameter_type::p_bool_t,     1 },
    { "temperature_penalty_ext_an_limit_h",     parameter_type::p_float32_t,  1 },
    { "temperature_penalty_ext_an_limit_l",     parameter_type::p_float32_t,  1 },
    { "temperature_penalty_ext_an_scale_l",     parameter_type::p_float32_t,  1 },
    { "cogging_compensator_coeffs",             parameter_type::p_float32_t,  1024 },
    { "cogging_compensator_lower_w_m_high",     parameter_type::p_float32_t,  1 },
    { "cogging_compensator_upper_w_m_low",      parameter_type::p_float32_t,  1 },
    { "cogging_compensator_upper_w_m_high",     parameter_type::p_float32_t,  1 },
    { "test_ls_v_dq_bias",                      parameter_type::p_float32_t,  1 },
    { "test_ls_v_dq_amplitude",                 parameter_type::p_float32_t,  1 },
    { "test_ls_test_freq_hz",                   parameter_type::p_float32_t,  1 },
    { "test_ls_test_time_ms",                   parameter_type::p_uint16_t,   1 },
    { "test_ls_dq_test_axis",                   parameter_type::p_enum8_t,    1 },
    { "test_rs_v_dq_test_amplitude",            parameter_type::p_float32_t,  1 },
    { "test_rs_test_time_ms",                   parameter_type::p_uint16_t,   1 },
    { "test_rs_dq_test_axis",                   parameter_type::p_enum8_t,    1 },
    { "test_step_response_amplitude",           parameter_type::p_float32_t,  1 },
    { "test_step_response_time_ms",             parameter_type::p_uint16_t,   1 },
    { "test_step_response_dq_test_axis",        parameter_type::p_enum8_t,    1 },
    { "host_sentry_active",                     parameter_type::p_bool_t,     1 },
    { "host_sentry_timeout_ms",                 parameter_type::p_uint32_t,   1 },
    { "host_sentry_wait_start_timeout_ms",      parameter_type::p_uint32_t,   1 },
    { "encoder_0_type",                         parameter_type::p_enum8_t,    1 },
    { "encoder_0_position_zero",                parameter_type::p_none_t,     0 },
    { "encoder_0_position_offset",              parameter_type::p_float32_t,  1 },
    { "encoder_0_direction",                    parameter_type::p_bool_t,     1 },
    { "encoder_0_theta_bypass",                 parameter_type::p_bool_t,     1 },
    { "encoder_0_theta_bypass_direction",       parameter_type::p_bool_t,     1 },
    { "encoder_0_linearisation_coeffs",         parameter_type::p_float32_t,  64 },
    { "encoder_0_error_rate_limit",             parameter_type::p_float32_t,  1 },
    { "encoder_0_error_rate",                   parameter_type::p_float32_t,  1 },
    { "encoder_0_position_offset_valid",        parameter_type::p_bool_t,     1 },
    { "encoder_0_linearisation_coeffs_valid",   parameter_type::p_bool_t,     1 },
    { "th_m_0",                                 parameter_type::p_float32_t,  1 },
    { "w_m_0",                                  parameter_type::p_float32_t,  1 },
    { "th_m_counts_0",                          parameter_type::p_uint32_t,   1 },
    { "th_m_encoder_0",                         parameter_type::p_float32_t,  1 },
    { "th_e_0",                                 parameter_type::p_float32_t,  1 },
    { "encoder_0_spi_frequency",                parameter_type::p_enum8_t,    1 },
    { "encoder_0_spi_phase",                    parameter_type::p_enum8_t,    1 },
    { "encoder_0_spi_polarity",                 parameter_type::p_enum8_t,    1 },
    { "encoder_0_spi_transfer_size",            parameter_type::p_enum8_t,    1 },
    { "encoder_0_spi_using_chip_select",        parameter_type::p_bool_t,     1 },
    { "encoder_0_spi_command",                  parameter_type::p_uint8_t,    0 },
    { "encoder_0_spi_position_mask",            parameter_type::p_uint8_t,    0 },
    { "encoder_0_spi_position_bits",            parameter_type::p_uint8_t,    1 },
    { "encoder_0_spi_masked_position_shift",    parameter_type::p_uint8_t,    1 },
    { "encoder_0_spi_masked_flag_shift",        parameter_type::p_uint8_t,    1 },
    { "encoder_0_spi_flag_mask",                parameter_type::p_uint8_t,    0 },
    { "encoder_0_incremental_cpr",              parameter_type::p_uint32_t,   1 },
    { "encoder_0_as5047p_last_rx",              parameter_type::p_uint16_t,   1 },
    { "estimator_0_type",                       parameter_type::p_enum8_t,    1 },
    { "estimator_0_theta_passthrough",          parameter_type::p_bool_t,     1 },
    { "estimator_0_tracking_loop_kp",           parameter_type::p_float32_t,  1 },
    { "estimator_0_tracking_loop_ki",           parameter_type::p_float32_t,  1 },
    { "estimator_0_tracking_loop_bandwidth_hz", parameter_type::p_float32_t,  1 },
    { "estimator_0_kalman_q",                   parameter_type::p_float32_t,  1 },
    { "estimator_0_kalman_r_w",                 parameter_type::p_float32_t,  1 },
    { "estimator_0_kalman_r_th",                parameter_type::p_float32_t,  1 },
    { "estimator_0_P_initial",                  parameter_type::p_float32_t,  4 },
    { "an_0_gain",                              parameter_type::p_float32_t,  1 },
    { "an_0_offset",                            parameter_type::p_float32_t,  1 },
    { "an_0_limit_warning_h",                   parameter_type::p_float32_t,  1 },
    { "an_0_limit_warning_l",                   parameter_type::p_float32_t,  1 },
    { "an_0_limit_error_h",                     parameter_type::p_float32_t,  1 },
    { "an_0_limit_error_l",                     parameter_type::p_float32_t,  1 },
    { "an_0_filter_fc_hz",                      parameter_type::p_float32_t,  1 },
    { "an_0",                                   parameter_type::p_float32_t,  1 },
    { "an_0_f",                                 parameter_type::p_float32_t,  1 },
    { "oscilloscope_sample_rate_hz",            parameter_type::p_uint32_t,   1 },
    { "oscilloscope_force_start",               parameter_type::p_none_t,     0 },
    { "oscilloscope_wait_trigger",              parameter_type::p_none_t,     0 },
    { "oscilloscope_is_done",                   parameter_type::p_bool_t,     1 },
    { "oscilloscope_stop",                      parameter_type::p_none_t,     0 },
    { "oscilloscope_trigger_source",            parameter_type::p_enum8_t,    1 },
    { "oscilloscope_trigger_level",             parameter_type::p_float32_t,  1 },
    { "oscilloscope_trigger_config",            parameter_type::p_enum8_t,    1 },
    { "oscilloscope_trigger_buffer_position",   parameter_type::p_uint32_t,   1 },
    { "oscilloscope_channel_0_source",          parameter_type::p_enum8_t,    1 },
    { "oscilloscope_channel_0",                 parameter_type::p_float32_t,  1792 },
    { "oscilloscope_channel_1_source",          parameter_type::p_enum8_t,    1 },
    { "oscilloscope_channel_1",                 parameter_type::p_float32_t,  1792 },
    { "oscilloscope_channel_2_source",          parameter_type::p_enum8_t,    1 },
    { "oscilloscope_channel_2",                 parameter_type::p_float32_t,  1792 },
    { "oscilloscope_channel_3_source",          parameter_type::p_enum8_t,    1 },
    { "oscilloscope_channel_3",                 parameter_type::p_float32_t,  1792 }
};

std::vector<std::string> const jcs::node_parameter::dev_motor_controller::controller_mode = {
    "current_dq",
    "voltage_dq",
    "test_align",
    "test_dq_l",
    "test_dq_r"
};

std::vector<std::string> const jcs::node_parameter::dev_motor_controller::controller_state = {
    "controller_off",
    "controller_calibrate",
    "controller_standby",
    "controller_run",
    "controller_error"
};

std::vector<std::string> const jcs::node_parameter::dev_motor_controller::encoder_type = {
    "encoder_none",
    "jcs_as5047p",
    "incremental",
    "jcs_network",
    "spi"
};

std::vector<std::string> const jcs::node_parameter::dev_motor_controller::encoder_spi_frequency = {
    "frequency_fpclk_on_2",
    "frequency_fpclk_on_4",
    "frequency_fpclk_on_8",
    "frequency_fpclk_on_16",
    "frequency_fpclk_on_32",
    "frequency_fpclk_on_64",
    "frequency_fpclk_on_128",
    "frequency_fpclk_on_256"
};

std::vector<std::string> const jcs::node_parameter::dev_motor_controller::encoder_spi_polarity = {
    "idle_low",
    "idle_high"
};

std::vector<std::string> const jcs::node_parameter::dev_motor_controller::encoder_spi_phase = {
    "first_edge",
    "second_edge"
};

std::vector<std::string> const jcs::node_parameter::dev_motor_controller::encoder_spi_transfer_size = {
    "num_bits_8",
    "num_bits_7",
    "num_bits_6",
    "num_bits_5",
    "num_bits_4"
};

std::vector<std::string> const jcs::node_parameter::dev_motor_controller::estimator_type = {
    "estimator_none",
    "tracking_loop",
    "kf"
};

std::vector<std::string> const jcs::node_parameter::dev_motor_controller::measurement_test_axis = {
    "measure_test_axis_d",
    "measure_test_axis_q"
};

// Oscilloscope sources
std::vector<std::string> const jcs::node_parameter::dev_motor_controller::oscilloscope_sources = {
    "mc_osc_chan_none",
    "mc_osc_sense_i_a",
    "mc_osc_sense_i_b",
    "mc_osc_sense_i_c",
    "mc_osc_foc_i_al",
    "mc_osc_foc_i_be",
    "mc_osc_foc_i_d",
    "mc_osc_foc_i_q",
    "mc_osc_foc_i_d_cmd",
    "mc_osc_foc_i_q_cmd",
    "mc_osc_foc_i_d_cmd_ff",
    "mc_osc_foc_i_q_cmd_ff",
    "mc_osc_foc_v_d_cmd",
    "mc_osc_foc_v_q_cmd",
    "mc_osc_foc_v_d_mod_cmd",
    "mc_osc_foc_v_q_mod_cmd",
    "mc_osc_foc_v_al_mod_cmd",
    "mc_osc_foc_v_be_mod_cmd",
    "mc_osc_foc_duty_a_cmd",
    "mc_osc_foc_duty_b_cmd",
    "mc_osc_foc_duty_c_cmd",
    "mc_osc_sense_v_a",
    "mc_osc_sense_v_b",
    "mc_osc_sense_v_c",
    "mc_osc_foc_v_al",
    "mc_osc_foc_v_be",
    "mc_osc_foc_v_d",
    "mc_osc_foc_v_q",
    "mc_osc_rotor_th_m",
    "mc_osc_rotor_th_e",
    "mc_osc_rotor_th_internal_m",
    "mc_osc_rotor_w_m",
    "mc_osc_sense_vdc",
    "mc_osc_i_mot",
    "mc_osc_i_bus"
};

// Oscilloscope trigger options
std::vector<std::string> const jcs::node_parameter::dev_motor_controller::oscilloscope_trigger_config = {
    "osc_trigger_rising",
    "osc_trigger_falling"
};

// Note: Must go below enum vectors or they won't compile in!
std::vector<jcs::parameter_enum> const jcs::node_parameter::dev_motor_controller::parameter_enums = {
    { "controller_mode",                 jcs::node_parameter::dev_motor_controller::controller_mode },
    { "controller_state",                jcs::node_parameter::dev_motor_controller::controller_state },
    { "encoder_0_type",                  jcs::node_parameter::dev_motor_controller::encoder_type },
    { "encoder_0_spi_frequency",         jcs::node_parameter::dev_motor_controller::encoder_spi_frequency },
    { "encoder_0_spi_polarity",          jcs::node_parameter::dev_motor_controller::encoder_spi_polarity },
    { "encoder_0_spi_phase",             jcs::node_parameter::dev_motor_controller::encoder_spi_phase },
    { "encoder_0_spi_transfer_size",     jcs::node_parameter::dev_motor_controller::encoder_spi_transfer_size },
    { "estimator_0_type",                jcs::node_parameter::dev_motor_controller::estimator_type },
    { "oscilloscope_trigger_source",     jcs::node_parameter::dev_motor_controller::oscilloscope_sources },
    { "oscilloscope_channel_0_source",   jcs::node_parameter::dev_motor_controller::oscilloscope_sources },
    { "oscilloscope_channel_1_source",   jcs::node_parameter::dev_motor_controller::oscilloscope_sources },
    { "oscilloscope_channel_2_source",   jcs::node_parameter::dev_motor_controller::oscilloscope_sources },
    { "oscilloscope_channel_3_source",   jcs::node_parameter::dev_motor_controller::oscilloscope_sources },
    { "oscilloscope_trigger_config",     jcs::node_parameter::dev_motor_controller::oscilloscope_trigger_config },
    { "test_rs_dq_test_axis",            jcs::node_parameter::dev_motor_controller::measurement_test_axis },
    { "test_ls_dq_test_axis",            jcs::node_parameter::dev_motor_controller::measurement_test_axis },
    { "test_step_response_dq_test_axis", jcs::node_parameter::dev_motor_controller::measurement_test_axis }
};

// Number of oscilloscope channels
int const jcs::node_parameter::dev_motor_controller::oscilloscope_n_channels = 4;
// Maximum oscilloscope sample length
int const jcs::node_parameter::dev_motor_controller::oscilloscope_sample_length = 1792;
// Default sample rate
int const jcs::node_parameter::dev_motor_controller::oscilloscope_sample_rate_hz = 30000;