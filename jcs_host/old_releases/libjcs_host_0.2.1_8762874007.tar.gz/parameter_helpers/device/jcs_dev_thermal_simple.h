// Copyright (c) 2024 Arbite Robotics Pty Ltd
// https://arbite.io
//
#ifndef DEV_THERMAL_SIMPLE_PARAMETER_H_
#define DEV_THERMAL_SIMPLE_PARAMETER_H_

#include <vector>
#include <string>
#include "jcs_parameter.h"

namespace jcs {
namespace node_parameter {
namespace dev_thermal_simple {
    // Parameters
    extern std::vector<jcs::parameter> const parameters;

    // Parameter enums
    extern std::vector<jcs::parameter_enum> const parameter_enums;
    extern std::vector<std::string> const low_controller_type;
    extern std::vector<std::string> const high_controller_type;
}
}
}
#endif