// Copyright (c) 2024 Arbite Robotics Pty Ltd
// https://arbite.io
//
#include "jcs_dev_brake_clutch.h"

// Parameters
std::vector<jcs::parameter> const jcs::node_parameter::dev_brake_clutch::parameters = {
    { "v_dc_limit_warning_h",            parameter_type::p_float32_t, 1 },
    { "v_dc_limit_warning_l",            parameter_type::p_float32_t, 1 },
    { "v_dc_limit_error_h",              parameter_type::p_float32_t, 1 },
    { "v_dc_limit_error_l",              parameter_type::p_float32_t, 1 },
    { "v_dc_filter_fc_hz",               parameter_type::p_float32_t, 1 },
    { "i_dc_0_limit_warning_h",          parameter_type::p_float32_t, 1 },
    { "i_dc_0_limit_warning_l",          parameter_type::p_float32_t, 1 },
    { "i_dc_0_limit_error_h",            parameter_type::p_float32_t, 1 },
    { "i_dc_0_limit_error_l",            parameter_type::p_float32_t, 1 },
    { "i_dc_0_filter_fc_hz",             parameter_type::p_float32_t, 1 },
    { "i_dc_1_limit_warning_h",          parameter_type::p_float32_t, 1 },
    { "i_dc_1_limit_warning_l",          parameter_type::p_float32_t, 1 },
    { "i_dc_1_limit_error_h",            parameter_type::p_float32_t, 1 },
    { "i_dc_1_limit_error_l",            parameter_type::p_float32_t, 1 },
    { "i_dc_1_filter_fc_hz",             parameter_type::p_float32_t, 1 },
    { "controller_0_mode",               parameter_type::p_enum8_t,   1 },
    { "controller_0_start",              parameter_type::p_none_t,    0 },
    { "controller_0_stop",               parameter_type::p_none_t,    0 },
    { "controller_0_is_running",         parameter_type::p_bool_t,    1 },
    { "controller_0_limit_out_h",        parameter_type::p_float32_t, 1 },
    { "controller_0_limit_out_l",        parameter_type::p_float32_t, 1 },
    { "controller_0_current_kp",         parameter_type::p_float32_t, 1 },
    { "controller_0_current_ki",         parameter_type::p_float32_t, 1 },
    { "controller_0_duty_scale",         parameter_type::p_float32_t, 1 },
    { "controller_0_duty_offset",        parameter_type::p_float32_t, 1 },
    { "controller_1_mode",               parameter_type::p_enum8_t,   1 },
    { "controller_1_start",              parameter_type::p_none_t,    0 },
    { "controller_1_stop",               parameter_type::p_none_t,    0 },
    { "controller_1_is_running",         parameter_type::p_bool_t,    1 },
    { "controller_1_limit_out_h",        parameter_type::p_float32_t, 1 },
    { "controller_1_limit_out_l",        parameter_type::p_float32_t, 1 },
    { "controller_1_current_kp",         parameter_type::p_float32_t, 1 },
    { "controller_1_current_ki",         parameter_type::p_float32_t, 1 },
    { "controller_1_duty_scale",         parameter_type::p_float32_t, 1 },
    { "controller_1_duty_offset",        parameter_type::p_float32_t, 1 },
    { "controller_0_R",                  parameter_type::p_float32_t, 1 },
    { "controller_0_L",                  parameter_type::p_float32_t, 1 },
    { "controller_1_R",                  parameter_type::p_float32_t, 1 },
    { "controller_1_L",                  parameter_type::p_float32_t, 1 },
    { "controller_0_test_l_v_bias",      parameter_type::p_float32_t, 1 },
    { "controller_0_test_l_v_amplitude", parameter_type::p_float32_t, 1 },
    { "controller_0_test_l_freq_hz",     parameter_type::p_float32_t, 1 },
    { "controller_0_test_l_time_ms",     parameter_type::p_uint16_t,  1 },
    { "controller_0_test_r_v_amplitude", parameter_type::p_float32_t, 1 },
    { "controller_0_test_r_time_ms",     parameter_type::p_uint16_t,  1 },
    { "controller_1_test_l_v_bias",      parameter_type::p_float32_t, 1 },
    { "controller_1_test_l_v_amplitude", parameter_type::p_float32_t, 1 },
    { "controller_1_test_l_freq_hz",     parameter_type::p_float32_t, 1 },
    { "controller_1_test_l_time_ms",     parameter_type::p_uint16_t,  1 },
    { "controller_1_test_r_v_amplitude", parameter_type::p_float32_t, 1 },
    { "controller_1_test_r_time_ms",     parameter_type::p_uint16_t,  1 },
};

std::vector<std::string> const jcs::node_parameter::dev_brake_clutch::controller_mode = {
    "controller_none",
    "current",
    "duty",
    "voltage",
    "test_l",
    "test_r",
};

// Note: Must go below enum vectors or they won't compile in!
std::vector<jcs::parameter_enum> const jcs::node_parameter::dev_brake_clutch::parameter_enums = {
    { "controller_0_mode", jcs::node_parameter::dev_brake_clutch::controller_mode },
    { "controller_1_mode", jcs::node_parameter::dev_brake_clutch::controller_mode },
};