# Build information

libjcs_host is built against:

libyaml-cpp-dev Version: 0.8.0+dfsg-6build1
g++ (Ubuntu 13.2.0-23ubuntu4) 13.2.0
